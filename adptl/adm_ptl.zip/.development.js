module.exports = {
    "authenticationMode": "MasterUser",
    "authorityUri": "https://login.microsoftonline.com/common/v2.0",
    "scope": "https://analysis.windows.net/powerbi/api",
    "POWER_BI_API_URL": "https://api.powerbi.com/",
    "LOIGN_URL": 'https://entrepportalapp-dv.azurewebsites.net/login?returnTo=',
    "LOGIN_REDIRECT_URL": 'https://entrepportalapp-dv.azurewebsites.net/#/authenticate?returnTo=',
    "HOST_URL": "https://entrepportalapp-dv.azurewebsites.net/",

}