const appSettings = {
  appCredentials: {
    clientId: '2a3ce98d-6590-4452-9557-788553a6ec32',
    tenantId: 'de9231de-45f4-4325-ae07-8ae72052517e',
    clientSecret: 'Mmm7Q~GTq5pCuEw06TfhDzVf~CPIIxNOMEAqP',
  },
  authRoutes: {
    redirect: `${process.env.DOMAIN}redirect`,
    error: '/error', // the wrapper will redirect to this route in case of any error
    unauthorized: '/unauthorized', // the wrapper will redirect to this route in case of unauthorized access attempt
  },
  remoteResources: {
    graphAPI: {
      endpoint: 'https://graph.microsoft.com/v2.0/me',
      scopes: ['user.read'],
    },
    armAPI: {
      endpoint: 'https://management.azure.com/tenants?api-version=2020-01-01',
      scopes: ['https://management.azure.com/user_impersonation'],
    },
  },
}

// sso
// clientId: "2a3ce98d-6590-4452-9557-788553a6ec32",
// tenantId: "de9231de-45f4-4325-ae07-8ae72052517e",
// clientSecret: "C0A.4hH5.FBZi_artL1m58Oix_7RrK~szD"

// graph
// clientId: "8c7873a4-c584-4dc3-bfae-684f82cf512c",
// tenantId: "267dcacd-0757-456e-93ab-89d7068ef6b4",
// clientSecret: "mA.I~~4~v1P.t85K0560Yx9-49FaHA_xdT"

// ssoclient
// clientId: "30e45d73-4df4-4338-b68a-9d6300479843",
// tenantId: "267dcacd-0757-456e-93ab-89d7068ef6b4",
// clientSecret: "_.Y4W_W~FEuZ~2~nbEc5Y14I96TNxtj.wU"

module.exports = appSettings
