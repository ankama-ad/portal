import { Injectable } from '@angular/core';
import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse } from '@angular/common/http';
import { Observable, throwError} from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { EncryptDecryptService } from '../src/shared/encrypt-decrypt.service';

@Injectable({
  providedIn: 'root'
})
export class EncryptDecryptInterceptor implements HttpInterceptor {

  constructor(private encryptDecryptService: EncryptDecryptService) { }

  /**
   * @description - intercept the http request 
   */
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    req = req.clone({ body: this.encryptDecryptService.encryptJSON(req.body) });

    return next.handle(req).pipe(
      map((event: HttpEvent<any>) => {
        if (event instanceof HttpResponse) {
          if(event.body && event.body.response){
           console.log(new Date().getTime())
           event.body.response = this.encryptDecryptService.decryptJSON(event.body.response) ;           
           console.log(new Date().getTime())
           console.log(event.body.response)
          }
        }
       return event;
      }),
      catchError(error => {
        if (error instanceof HttpErrorResponse) {
          //handle http errors based on status
        }
        return throwError(() => error);
      })
    );
  }
}