import { ThisReceiver } from '@angular/compiler';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { ApiService } from '../src/app/services/api.service';
import { AuthenticationService } from './app/services/authentication.service';
import { environment } from './environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(
    private _apiService: ApiService,
    private _router: Router,
    private authService: AuthenticationService
  ) { }

  canActivate(): boolean {
    if (this._apiService.LoggedIn()) {
      return true
    }
    else {
      // this.authService.login();      
      const { hash, origin } = document.location;
      const path = hash.indexOf('#') > -1 ? hash.substr(1) : hash;
      if (!environment.production) {
        window.location.href = environment.SIGNIN_URL + path + '&origin=' + origin;
      } else {
        window.location.href = origin + environment.SIGNIN_URL + path + '&origin=' + origin;
      }
      return false;
    }
  }
}
