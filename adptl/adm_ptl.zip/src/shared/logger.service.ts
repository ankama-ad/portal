import { Injectable } from '@angular/core';
import { environment } from '../environments/environment';
import { ApiService } from '../app/services/api.service';
import { BaseAPIService } from '../app/baseAPIService';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

export class LoggingLevel {
  public static Info = 'Info';
  public static Warnings = 'Warnings';
  public static Errors = 'Errors';
}

@Injectable({
  providedIn: 'root'
})

export class LoggerService extends BaseAPIService {
  baseApiUrl = ''; // `${environment.baseApiUrl}logger/`;
  headers: HttpHeaders;
  constructor(private apiService: ApiService,public http: HttpClient) {
    super(http);
    this.baseApiUrl = `${this.apiUrl}logger/`;
    this.headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*'
    });
   }

  /**
   * Method to log centralized logs based on environment configuration
   * @param message 
   * @param level 
   */
  log(message: any, level: LoggingLevel): void {
    console.log('in log service');
    console.log(environment.enableLogger);
    if (!environment.enableLogger) {
      switch (level) {
        case LoggingLevel.Errors:
          console.error(message);
          break;
        case LoggingLevel.Warnings:
          console.warn(message);
          break;
        case LoggingLevel.Info:
          console.info(message);
          break;
        default:
          console.debug(message);
      }
    }
    else {
      this.sendToLogger(message, level).subscribe(()=>{});
    }
  }


  /**
   * Method to call service for sending request parameters
   * @param message 
   * @param level 
   */
  sendToLogger(message, level) {
    console.log('sending')
    const req = {
      userId: '123',
      userName: 'xyz',
      logLevel: level,
      logDescription: message
    }
       return this.http.post<any[]>(this.baseApiUrl + "logerrors", req);
  }

  /**
   * Method to log error
   * @param message 
   */
  logError(message: string) {
    this.log(message, LoggingLevel.Errors);
  }

  /**
   * Method to log warning
   * @param message 
   */
  logWarning(message: string) {
    this.log(message, LoggingLevel.Warnings);
  }
/**
   * Method to log info
   * @param message 
   */
  logInfo(message: string) {
    this.log(message, LoggingLevel.Info);
  }

}
