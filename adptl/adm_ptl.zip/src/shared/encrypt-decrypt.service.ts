import { Injectable } from '@angular/core';
import {environment} from "../environments/environment";
import * as CryptoJS from 'crypto-js';


@Injectable({
  providedIn: 'root'
})
export class EncryptDecryptService {

  constructor() { }

  /**
   * Method to encrypt 
   * @param req object to be encrypted 
   * @returns encrypted based on Algorithm
   */
   encryptJSON(req: {}) {
    return {data: CryptoJS.AES.encrypt(JSON.stringify(req), environment.ENC_KEY).toString()};
  }

  /**
   * Method to decrypt
   * @param res string to be decrypted 
   * @returns decrypted response
   */
  decryptJSON(res: string) {
    debugger;
    return JSON.parse(CryptoJS.AES.decrypt(res, environment.ENC_KEY).toString(CryptoJS.enc.Utf8));
  }
}
