import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedReportsRoutingModule } from './shared-reports-routing.module';
import { SharedReportsComponent } from './shared-reports.component';


@NgModule({
  declarations: [
    SharedReportsComponent
  ],
  imports: [
    CommonModule,
    SharedReportsRoutingModule
  ]
})
export class SharedReportsModule { }
