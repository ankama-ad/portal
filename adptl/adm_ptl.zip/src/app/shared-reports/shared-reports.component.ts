import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shared-reports',
  templateUrl: './shared-reports.component.html',
  styleUrls: ['./shared-reports.component.scss']
})
export class SharedReportsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
