import { HttpClient } from "@angular/common/http";

export class EnvService {

    // The values that are defined here are the default values that can
    // be overridden by env.js
  
    // API url
    public apiUrl = '';
    public NODE_ENV ='';  
    public BASE_API_URL =  '';    
    public REDIRECT_URL =  'http://localhost:8080/login?returnTo=';
    // Whether or not to enable debug mode
    public enableDebug = true;
      
  
  }