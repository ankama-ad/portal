import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
//import { LoginComponent } from './views/login/login.component';

// Import Containers
import { DefaultLayoutComponent } from './containers';
import { AuthGuard } from '../auth.guard';
import { MsalGuard } from '@azure/msal-angular';
import { LoginComponent } from './views/login/login.component';
import { AuthenticationComponent } from './views/authentication/authentication.component';


export const routes: Routes = [

  // {
  //   path: 'login',
  //   component: LoginComponent,
  //   data: {
  //     title: 'Login Page'
  //   }
  // }, 
  {
    path: 'login', component: LoginComponent,
  },
  { path: 'authenticate', component: AuthenticationComponent },
  {
    path: '',
    component: DefaultLayoutComponent,
    data: {
      title: 'Home'
    },
    // canActivate: [AuthGuard],
    children: [

      {
        path: 'dashboard',
        loadChildren: () => import('./views/dashboard/dashboard.module').then(m => m.DashboardModule)
      },
      {
        path: 'reports',
        loadChildren: () => import('./views/reports/reports.module').then(m => m.ReportsModule)
      },
      {
        path: 'usermanagement',
        loadChildren: () => import('./views/configurations/user-management/user-management.module').then(m => m.UserManagementModule)
      },
      {
        path: 'settings',
        loadChildren: () => import('./views/configurations/settings/settings.module').then(m => m.SettingsModule)
      },

      { path: 'contentManagement', loadChildren: () => import('./content-management/content-management.module').then(m => m.ContentManagementModule) },

      { path: 'reportManagement', loadChildren: () => import('./report-management/report-management.module').then(m => m.ReportManagementModule) },

      { path: 'feedbackManagement', loadChildren: () => import('./feedback-management/feedback-management.module').then(m => m.FeedbackManagementModule) },

      { path: 'adminDashboard', loadChildren: () => import('./admin-dashboard/admin-dashboard.module').then(m => m.AdminDashboardModule) },

      { path: 'reportAccess', loadChildren: () => import('./report-access/report-access.module').then(m => m.ReportAccessModule) },
      
      { path: 'sharedReports', loadChildren: () => import('./shared-reports/shared-reports.module').then(m => m.SharedReportsModule) },

      { path: 'favourites', loadChildren: () => import('./favourites/favourites.module').then(m => m.FavouritesModule) },
    
      {
        path: '', redirectTo: '/dashboard', pathMatch: 'full',
      },
      {
        path: 'code',
        redirectTo: '/dashboard', pathMatch: 'full',
      },

    ]
  },

  
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { relativeLinkResolution: 'legacy', useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }

