import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-access',
  templateUrl: './report-access.component.html',
  styleUrls: ['./report-access.component.scss']
})
export class ReportAccessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
