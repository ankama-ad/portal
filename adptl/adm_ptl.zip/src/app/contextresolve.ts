import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from "@angular/router";
import { Observable } from "rxjs";
import { EnvService } from "./env.service";

@Injectable({ providedIn: 'root' })
export class ContextResolver implements Resolve<EnvService> {
  constructor(private http: HttpClient) {}
  resolve(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<any>|Promise<any>|any {
    return this.http.get(window['__env']['clientEnvapiUrl'] + '/api/clientcontext'); // this.env.getHero(route.paramMap.get('id'));
  }
}