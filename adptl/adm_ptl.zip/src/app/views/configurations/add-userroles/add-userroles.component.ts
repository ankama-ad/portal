import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { AfterViewInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { UserRolesService } from '../../../services/userRoles.service';
import { userRoles } from '../departments/models/userRoles';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';


const ALPHA_NUMERIC_REGEX = /^[a-zA-Z0-9\. \( \) _ \-]+$/;
const ALPHA_NUMERIC_VALIDATION_ERROR = { alphaNumericError: 'only alpha numeric values are allowed' }
@Component({
  selector: 'app-add-userroles',
  templateUrl: './add-userroles.component.html',
  styleUrls: ['./add-userroles.component.scss']
})
export class AddUserrolesComponent implements OnInit {

  model: userRoles=<userRoles>{};
  userRoleTypes: any[] = [];
  userRolesForm: FormGroup;
  permissions:Array<any>
  isValid = false;
  constructor(private router: Router, private userRolesService: UserRolesService, private dialog: MatDialog,  private _snackBar: MatSnackBar) {     
    if(this.router.getCurrentNavigation().extras.state) {
      this.model = <userRoles>this.router.getCurrentNavigation().extras.state;
    }
  }

  ngOnInit(): void {
    this.createForm();
    this.loadUserRoleTypes();  
    this.loadRoleTypePermissions();
    
  }

  loadUserRoleTypes(): void {
    this.userRolesService.getAdminRoleTypess().subscribe((c:any) => {
      if (c.metadata.responseStatus === 200 && c.metadata.rows != 0) {
        debugger;
        this.userRoleTypes = c.response;
      }
    });
  }

   loadRoleTypePermissions(): void {      
    
    this.userRolesService.getAdminRoleTypePermissions(this.userRolesForm.get('adminRoleTypeId').value)
    .subscribe((res:any) => {   
       if (res.metadata.responseStatus === 200 && res.metadata.rows != 0) {
      this.permissions = res.response;              
       }
    })
  }

  createForm():void {    
    this.userRolesForm = new FormGroup({
      adminRoleTypeId: new FormControl('1'),
      adminRoleName: new FormControl('', [Validators.required,  Validators.minLength(3),this.alphaNumericValidator]),
      adminRoleDescription: new FormControl(''),
      isActive: new FormControl(''),             
      isDefaultRole: new FormControl('')
    });
    // if(this.model.accessLevelId){
    //   // this.userRolesForm.patchValue(this.model);
    // }
  }

  public hasError = (controlName: string, errorName: string) => {    
    return this.userRolesForm.get(controlName).hasError(errorName);
  }
  
  setPermission(event:any, item:any, key: string){
    console.log(event);
    item[key]= !!event.val;
  }
  addUserRole() {    
    if(this.userRolesForm.invalid){
      return;
    }
    
    let roleWithPermission = {...this.userRolesForm.value,  permissions: this.getflattenedPermissionfromTreeNodes() };
    this.userRolesService.addUserRole(roleWithPermission).subscribe(res => {
      this.router.navigate(['/settings'], {state: {activeTabIndex: 2}});
      this._snackBar.open('User Roles added successfully', '', {
        horizontalPosition: 'center',
        verticalPosition: 'top',
        duration: 3000,
      });
    },
      err => {
        this._snackBar.open('Error in saving User Roles', '', {
          horizontalPosition: 'center',
          verticalPosition: 'top',
          duration: 3000,
        });
      }
    );
  }

  updateUserRole() {    
    if(this.userRolesForm.invalid){
      return;
    }
    this.userRolesService.updateUserRole(this.userRolesForm.value).subscribe(res => {
      this.router.navigate(['/settings'], {state: {activeTabIndex: 1}});
      this._snackBar.open('User Roles updated successfully', '', {
        horizontalPosition: 'center',
        verticalPosition: 'top',
        duration: 3000,
      });
    },
      err => {
        this._snackBar.open('Error in updated User Roles', '', {
          horizontalPosition: 'center',
          verticalPosition: 'top',
          duration: 3000,
        });
      }
    );
  }

  

  cancel(){
    this.router.navigate(['/settings'], {state: {activeTabIndex: 0}});
    //this.router.navigate(['/settings/departments']);
  }

  getflattenedPermissionfromTreeNodes(){
    let flattenedCollection = [];
    let bfs = function(tree, key, collection) {
      if (!tree[key] || tree[key].length === 0) {
        collection.push(tree);
        return;
      }
      for (var i = 0; i < tree[key].length; i++) {
        var child = tree[key][i];
        bfs(child, key, collection);
      }
      return;
    };
    this.permissions.forEach(c => {
      bfs(c, "children", flattenedCollection);  
    })
    return flattenedCollection;
  }



alphaNumericValidator(control: FormControl): ValidationErrors | null {
    return ALPHA_NUMERIC_REGEX.test(control.value) ? null : ALPHA_NUMERIC_VALIDATION_ERROR;
}


}
