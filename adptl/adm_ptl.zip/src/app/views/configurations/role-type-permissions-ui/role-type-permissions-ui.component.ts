import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { AfterViewInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserRolesService } from '../../../services/userRoles.service';
import { userRoles } from '../departments/models/userRoles';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
@Component({
  selector: 'app-role-type-permissions-ui',
  templateUrl: './role-type-permissions-ui.component.html',
  styleUrls: ['./role-type-permissions-ui.component.scss']
})
export class RoleTypePermissionsUiComponent implements OnInit {

  @Input() isEdit = false;
  @Input() isConfig = false;

  @Output() permissionsChange = new EventEmitter();
  permissionsValue = [];
  get permissions() {
    return this.permissionsValue;
  }
  set permissions(val) {
    this.permissionsValue = val;
    this.permissionsChange.emit(this.permissionsValue);
  }
  
  constructor(private route: ActivatedRoute, private router: Router, private userRolesService: UserRolesService, private dialog: MatDialog, private _snackBar: MatSnackBar) {

  }

  ngOnInit(): void {
  }

}
