import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RoleTypePermissionsUiComponent } from './role-type-permissions-ui.component';

describe('RoleTypePermissionsUiComponent', () => {
  let component: RoleTypePermissionsUiComponent;
  let fixture: ComponentFixture<RoleTypePermissionsUiComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RoleTypePermissionsUiComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RoleTypePermissionsUiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
