import { Component, OnInit } from '@angular/core';
import { DepartmentsService } from '../../../../services/departments.service';

@Component({
  selector: 'app-department-stats',
  templateUrl: './department-stats.component.html',
  styleUrls: ['./department-stats.component.scss']
})
export class DepartmentStatsComponent implements OnInit {
  stats: any = {};

  constructor(private departmentsService: DepartmentsService,) { }

  ngOnInit(): void {
    this.loadDepartmentStats();
  }

  loadDepartmentStats(){
    this.departmentsService.getDepartmentStats().subscribe(res => {
     if (res.metadata.responseStatus === 200 && res.metadata.rows != 0) {
        this.stats = res.response;        
      }
    })
  }
}
