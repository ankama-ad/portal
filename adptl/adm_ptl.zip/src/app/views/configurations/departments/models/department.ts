export interface Department {
    departmentId: number,
    departmentPrefix:string,
    departmentName:string,
    departmentDescription: string,  
    admins: string[],
    createdOn: string,  
  }