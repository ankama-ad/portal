export interface Logger {
    Id: number,
    userId:number,
    userName:string,
    logLevel:string,
    logDescription: string,  
     
  }