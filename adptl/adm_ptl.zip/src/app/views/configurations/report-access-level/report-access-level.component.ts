import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-access-level',
  templateUrl: './report-access-level.component.html',
  styleUrls: ['./report-access-level.component.scss']
})
export class ReportAccessLevelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
