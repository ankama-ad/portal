import { Component, OnInit } from '@angular/core';
import { AfterViewInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { MatCheckboxChange } from '@angular/material/checkbox';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSelectChange } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Observable, startWith } from 'rxjs';
import { map } from 'rxjs/internal/operators/map';
import { DepartmentsService } from '../../../services/departments.service';
import { UsersService } from '../../../services/users.service';

interface IUser {
  adminRole: string;
  coworkerId: number; 
  departmentName: string ; 
  name: string;
  groups: number ;
  accessibleReports: number;
  lastActivity: string;
}


@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss']
})
export class UsersComponent implements OnInit {

  
  displayedColumns: string[] = ['coworkerId','name','adminRole',  'departmentName',  'groups', 'accessibleReports', 'lastActivityDate'];
  users: IUser[] = [];
  departments:any[] = [];
  departmentName: string;
  // dataSource = new MatTableDataSource(this.departments);
  dataSource: MatTableDataSource<IUser> = new MatTableDataSource(this.users);
  filteredOptions: Observable<any[]>;
  departmentFilterCtrl = new FormControl();
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  statusFilter = new FormControl('');
  searchFilterCtrl = new FormControl('');

  filterValues: any = {
    departmentName: '',
    name: ''
  }

  constructor(private router: Router, private usersService: UsersService, private departmentsService: DepartmentsService, private dialog: MatDialog,  private _snackBar: MatSnackBar) { }


  ngOnInit(): void {
    this.loadUsers();
    this.loadDepartments();    
    this.fieldListener();
  }

  private fieldListener() {
    this.departmentFilterCtrl.valueChanges
      .subscribe(
        status => {
          this.filterValues.departmentName = status;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )
    this.searchFilterCtrl.valueChanges
      .subscribe(
        source => {
          this.filterValues.name = source;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )
  }
  

  private _filter(value: string): any[] {    
    const filterValue = (value + '').toLowerCase();
    return this.departments.filter(option => option.departmentName.toLowerCase().includes(filterValue));
  }

  ngAfterViewInit() {

  } 

  loadDepartments(){
    this.departmentsService.getDepartments().subscribe(res => {
      if (res.metadata.responseStatus === 200 && res.metadata.rows != 0) {
        this.departments = res.response;   
        this.filteredOptions = this.departmentFilterCtrl.valueChanges.pipe(
          startWith(''),
          map(value => value ? this._filter(value) : this.departments)
        );   
      }
    })
  }

  loadUsers(){
    this.usersService.getUsers().subscribe((res:any) => {
      if (res.metadata.responseStatus === 200 && res.metadata.rows != 0) {
        this.users = res.response;
        this.dataSource = new MatTableDataSource(this.users);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      }
    })
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  } 
  
  filterDepartments(event: MatAutocompleteSelectedEvent){
    console.log(event.option);
    if(event.option.value){
      console.log('apply filter', event);
      let res = this.users.filter(c => c.departmentName == event.option.value)
      this.dataSource.filter = event.option.value;
    } else {
      console.log('reset filter')
      this.dataSource.filter = event.option.value;
    }
  }

  private createFilter(): (user: IUser, filter: string) => boolean {
    let filterFunction = function (user, filter): boolean {
      let searchTerms = JSON.parse(filter);
      return user.departmentName.indexOf(searchTerms.departmentName) !== -1
        && user.name.indexOf(searchTerms.name) !== -1;
    }

    return filterFunction;
  }

}
