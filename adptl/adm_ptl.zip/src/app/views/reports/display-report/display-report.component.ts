import { Component, OnInit } from '@angular/core'
import { ActivatedRoute, Route, Router } from '@angular/router'
import { report } from 'process'

@Component({
  selector: 'app-display-report',
  templateUrl: './display-report.component.html',
  styleUrls: ['./display-report.component.scss'],
})
export class DisplayReportComponent implements OnInit {
  reportId = 0
  reportParams = { id: 0 }
  constructor(private router: Router) {
    let params = <any>(this.router.getCurrentNavigation().extras.state.report);
    if (params) {
      this.reportParams = params;
    }
  }

  ngOnInit(): void {
   
    // this.reportId = <any>(this.route.snapshot.paramMap.get('report'));
  }
}
