import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../../services/authentication.service';
import { ReportService } from '../../../services/reportService';

@Component({
  selector: 'app-reports-list',
  templateUrl: './reports-list.component.html',
  styleUrls: ['./reports-list.component.scss']
})
export class ReportsListComponent implements OnInit {
  reports: any = [];
  constructor(private reportService: ReportService, private router: Router, private authService: AuthenticationService,) { }

  ngOnInit(): void {
    this.getReprots();
  }

  getReprots() {
    // this.authService.user.username 
    this.reportService.getReports().subscribe( res => {
      if (res.metadata.responseStatus === 200 && res.metadata.rows != 0) {       
        this.reports = res.response;
      }
    },
    err => {
      console.log("err", err);
    })
  }

  loadReport(report){    
    this.router.navigate(['/reports/details/', report.id], {state: {report: report}});
  }


}
