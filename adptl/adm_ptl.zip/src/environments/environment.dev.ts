
export const environment = {
  production: false,
  enableLogger:true,
  test: true,
  baseApiUrl: 'https://entrepportalapp-dv.azurewebsites.net/api/',
  appId: '6878a486-4dea-4baa-9713-8f99f9d63052',
  REDIRECT_URL: 'https://entrepportalapp-dv.azurewebsites.net/login?returnTo=',
  ENC_KEY: "abc123abc"
};
