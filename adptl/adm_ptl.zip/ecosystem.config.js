module.exports = {
    apps: [
        {
            name: "portal",
            script: "./server.js",
            watch: true,
            env: {
                "PORT": 8080,
                "NODE_ENV": ""
            },
            env_local: {
                "PORT": 8080,
                "NODE_ENV": ""
            },
            env_development: {
                "PORT": 8080,
                "NODE_ENV": "development",
            },
            env_qa: {
                "PORT": 8080,
                "NODE_ENV": "qa",
            },
            env_production: {
                "PORT": 8080,
                "NODE_ENV": "production",
            }
        }
    ]
}