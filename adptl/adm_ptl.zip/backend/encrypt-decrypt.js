var crypto = require('crypto-js');
const { logger, logInfo, logError } = require('./logger');

module.exports.encryptJSON = function encryptJSON(res) {
    return { data: crypto.AES.encrypt(JSON.stringify(res), process.env.ENC_KEY).toString() };
}

module.exports.encryptResponse = function encryptJSON(res) {
    //console.log('Started encrypting respnse', res);    
    // logInfo({
    //     level: 'info', message: 'Started encrypting response: ' + res,
    //     hostname: '', port: '',
    //     username: 'ankam.bollimuntha@cdw.com', req: ''
    // });
    try {
        if (res.response && res.response !== 'undefined') {
            res.response = crypto.AES.encrypt(JSON.stringify(res.response), process.env.ENC_KEY).toString()
        }
        // console.log('encrypted request', res);
    } catch (ex) {
        console.log('exception in Encryption ', ex.message);
        console.log(ex.stack);
        logError({
            level: 'error', message: 'Error in Encrypting request: ' + ex.message,
            hostname: '', port: '',
            username: 'ankam.bollimuntha@cdw.com', req: ''
        });
    }
    return res;
}

module.exports.decryptJSON = function decryptJSON(req) {
    //console.log('started decrypting request', req);
    let text = '';
    // logInfo({
    //     level: 'info', message: 'Started decrypting Request: ' + req,
    //     hostname: '', port: '',
    //     username: 'ankam.bollimuntha@cdw.com', req: ''
    // });
    try {
        text = JSON.parse(crypto.AES.decrypt(req, process.env.ENC_KEY).toString(crypto.enc.Utf8));
        //console.log('decrypted request', req);
    } catch (ex) {
        console.log('exception in decryption ', ex.message);
        logError({
            level: 'error', message: 'Error in decrypting request: ' + ex.message,
            hostname: '', port: '',
            username: 'ankam.bollimuntha@cdw.com', req: ''
        });
    }

    return text;
}


