var dbContext = require("./services/dbcontext");
const { logger } = require("./logger");
const { performance } = require('perf_hooks');


const apiResponse = {
    metadata: { about: '', rows: 0, responseStatus: 200, responseTime: 0 },
    response: {}
};

module.exports.apiResponse = apiResponse;

module.exports.componentWrapper = async (req, res) => {

    let startTime = performance.now();
    let response = {};
    let result = apiResponse;
    let sqlOptions = {};
    try {
        sqlOptions.queryParams = req.options.queryParams;
        sqlOptions.query = req.options.query;
        response = await dbContext.executeSql(sqlOptions)
        result.metadata.rows = response.result[1];
        result.metadata.responseStatus = response.status;
        result.response = response.result[0];
        // result.metadata.rows = response.result.rowsAffected;
        result.metadata.responseStatus = response.status;
    } catch (err) {
        logError({ level: 'error', message: err.message,  hostname: req.hostname, port: req.port,
                 username: 'ankam.bollimuntha@cdw.com', req: (req.protocol + "://" + req.get('host') + req.originalUrl) })
        // res.send(ex);
        response.logInfo.level = "error";
        response.logInfo.status = 500;
        // response.logInfo.message = logInfo.message + " : " + err.message;
        response.status = 500;
        response.result = err.message;
        
        
        throw err;
    } finally {       
        result.metadata.responseTime = performance.now() - startTime;
        return result;
    }

}