// const { DefaultAzureCredential } = require("@azure/identity");
// const { SecretClient } = require("@azure/keyvault-secrets");

// get credentials from managed identity
// const credential = new DefaultAzureCredential();

// // Build the URL to reach your key vault
// const vaultName = process.env.KEY_VAULT_NAME || "EntRepKeyVault-DV";
// const url = `https://${vaultName}.vault.azure.net`;

// // Lastly, create our secrets client and connect to the service
// const client = new SecretClient(url, credential);

// const secretName = "";

// function main() {
//   client.getSecret(secretName).then(res => { 
//     console.log(`Latest version of the secret ${secretName}: `, res);

//   });
// //   const specificSecret = await client.getSecret(secretName, { version: latestSecret.properties.version! });
// //   console.log(`The secret ${secretName} at the version ${latestSecret.properties.version!}: `, specificSecret);
// }

// client.setSecret("ConnectionString", 'Driver={ODBC Driver 17 for SQL Server};server=entrep-sqldb-cdw-usncz-dv-svr.database.windows.net;database=entrep-sqldb-cdw-usncz-dv-ReportingDB;Authentication=ActiveDirectoryIntegrated;')
// .then(res => { 
// console.log (res);
// });
module.exports = {}; // client;