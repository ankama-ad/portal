// logger.js
const winston = require('winston');
const winstonAzureBlob = require("winston3-azureblob-transport");
const loggerService = require('./services/loggerService');

const getRequestLogFormatter = ()  => {
    const {combine, timestamp, printf} = winston.format;

    return combine(
        timestamp(),
        printf(info => {           
            return `${info.timestamp} ${info.level}: ${info.hostname}${info.username}${info.originalUrl}`;
        })
    );
}

const logFormat = winston.format.combine(
  winston.format.timestamp({ format: "YYYY-MM-DD HH:mm:ss" }),
  winston.format.printf((info) => `${info.level} : ${info.timestamp} - ${info.message}`)
);


const formatter2 = winston.format.combine(
  // winston.format.colorize(),
  winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
  winston.format.splat(),
  winston.format.printf((info) => {
      const { timestamp, level, message, ...meta } = info;
      return `${timestamp}  [${level}]:  ${message} ${Object.keys(meta).length ? JSON.stringify(meta, null, 2) : ''}
      `;
  }),
);

const options = {
  file: {
      format: formatter2,
      filename: 'logs/error.log',        
      level: 'error',
      colorize: false,
      handleExceptions: true
  },
  info: {
      format: formatter2,
      filename: 'logs/info.log',        
      level: 'info',
      colorize: false,
      handleExceptions: true
  }
}

const transport = [
  // new winstonAzureBlob({
  //   account: {
  //     name: process.env.BLOB_NAME,
  //     key: process.env.BLOB_KEY
  //   },
  //   containerName: "exception-logs",
  //   blobName: "info-"+new Date().toISOString().slice(0, 10)+".log",
  //   level: "info",
  //   bufferLogSize: 1,
  //   syncTimeout: 0,
  //   rotatePeriod: "",
  //   eol: "\n"
  // }),
  //  new (winstonAzureBlob)({
  //   account: {
  //     name: process.env.BLOB_NAME,
  //     key: process.env.BLOB_KEY
  //   },
  //   containerName: "exception-logs",
  //   blobName: "error-"+new Date().toISOString().slice(0, 10)+".log",
  //   level: "error",
  //   bufferLogSize: 1,
  //   syncTimeout: 0,
  //   rotatePeriod: "",
  //   eol: "\n"
  // }),
  //  new (winstonAzureBlob)({
  //   account: {
  //     name: process.env.BLOB_NAME,
  //     key: process.env.BLOB_KEY
  //   },
  //   containerName: "exception-logs",
  //   blobName: "warning-"+new Date().toISOString().slice(0, 10)+".log",
  //   level: "warning",
  //   bufferLogSize: 1,
  //   syncTimeout: 0,
  //   rotatePeriod: "",
  //   eol: "\n"
  // }),
  new winston.transports.File(options.info),
  new winston.transports.File(options.file),
]







const logger = winston.createLogger({
  format: getRequestLogFormatter(),
  handleExceptions: true,
  colorize: false,
  transports: transport
});


function logError(err) {
    logger.error({ message: messageFormatter(err) });
    loggerService.insertBackendLog('17474', err.username, 'error', messageFormatter(err), err.req);
}
function logWarning(err) {
    logger.warning({ message: messageFormatter(err) });
        loggerService.insertBackendLog('111', 'abc', 'warning', messageFormatter(err));
}
function logInfo(err) {
  console.log('info', err);
    logger.info({ message: messageFormatter(err) });
    loggerService.insertBackendLog('17474', err.username, 'info', messageFormatter(err), err.req);
}
function logErrorMiddleware(err, req, res, next) {
    logError(err);
    next(err);
}

function returnError(err, req, res, next) {
    res.status(err.statusCode || 500).send(err.message);
}

function messageFormatter(msg) {
    try {
        return JSON.stringify(msg);
    }
    catch {
        return msg;
    }
}

function isOperationalError(error) {
    if (error instanceof BaseError) {
        return error.isOperational;
    }
    return false;
}

logger.stream = {
  write: function(message, encoding){
      logger.info(message);
  }
};

module.exports = {
  logger,
  logError,
  logWarning,
  logInfo,
  logErrorMiddleware,
  returnError,
  isOperationalError
}

