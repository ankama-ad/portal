let customEnv = require('custom-env');
if (customEnv) {
    customEnv.env(process.env.NODE_ENV);
} else {
    let dotenv = require('dotenv');
    if (dotenv) {
        dotenv.config({ path: './envconfig/' + process.env.NODE_ENV + '/.env' })
    }
}
console.log("ENV : ", process.env.NODE_ENV);

module.exports.setupConfig = (async () => {
    try {
        // const vault = require('./keyVault');
        // const azureIdentity = require("@azure/identity");        
        // const appConfig = require("@azure/app-configuration");
        // const appcnf = await vault.getSecret("EnterpriseReporting-AppConfiguration");
        // const appconfigClient = new appConfig.AppConfigurationClient(appcnf.value);
        // const LOGIN_REDIRECT_URL = await appconfigClient.getConfigurationSetting({
        //     key: "LOGIN_REDIRECT_URL",
        // });
        // console.log(LOGIN_REDIRECT_URL.value);


        // const { BlobServiceClient } = require("@azure/storage-blob");
        // const { DefaultAzureCredential } = require("@azure/identity");
        // const account = "usnczcdwentrepapplogs";
        // const defaultAzureCredential = new DefaultAzureCredential();
        // const blobServiceClient = new BlobServiceClient(
        //     `https://${account}.blob.core.windows.net`,
        //     defaultAzureCredential
        // );
        // const containerName = "logs";
        // const containerClient = blobServiceClient.getContainerClient(containerName);

        // const content = "Hello world!";
        // const blobName = "newblob" + new Date().getTime();
        // const blockBlobClient = containerClient.getBlockBlobClient(blobName);
        // const uploadBlobResponse = await blockBlobClient.upload(content, content.length);
        // console.log(`Upload block blob ${blobName} successfully`, uploadBlobResponse.requestId);
    } catch (ex) {
        console.log(ex);
    }
})();
//module.exports = require('../.development');

