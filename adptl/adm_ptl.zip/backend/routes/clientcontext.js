
const express = require("express");
const router = express.Router();


router.get('/',  async (req, res) => {
 const  env = { 
     NODE_ENV: process.env.NODE_ENV,  
     BASE_API_URL: process.env.BASE_API_URL || 'http://localhost:8080/api/',     
     REDIRECT_URL: process.env.REDIRECT_URL || 'http://localhost:8080/login?returnTo='
    }    
res.send(env);
});

module.exports = router;