
const express = require("express");
const router = express.Router();

const { Op, QueryTypes } = require("sequelize");
// const { DefaultAzureCredential } = require("@azure/identity");
var dbContext = require("../services/dbcontext");
const { token } = require('morgan');
const guid = 'f60ebcf7-b566-48ec-a40f-4edf15a6b095-4edf15a6b095';
/**
 * @swagger
 * components:
 *   schemas:
 *     NewUser:
 *       type: object
 *       properties:
 *         name:
 *           type: string
 *           description: The user's name.
 *           example: Leanne Graham
 *     User:
 *       allOf:
 *         - type: object
 *           properties:
 *             id:
 *               type: integer
 *               description: The user ID.
 *               example: 0
 *             accessLevelId:
 *               type: integer
 *               description: The user ID.
 *               example: 0
 *             accessLevelName:
 *               type: integer
 *               description: The user ID.
 *               example: 0
 *         - $ref: '#/components/schemas/NewUser'
 *     AdminRole:
 *           properties:
 *             adminRoleId:
 *               type: integer
 *               description: The user ID.
 *               example: 0
 *             adminRoleName:
 *               type: string
 *               description: admin Role Name.
 *               example: Portal Admin (Default)
 *             adminRoleDescription:
 *               type: string
 *               description: Portal Admin (Default) description.
 *               example: Portal Admin (Default) description.
 *     QModel:
 *           properties:
 *             token:
 *               type: string
 *               description: The user ID.
 *               example: 0
 *             queryType:
 *               type: string
 *               description: select.
 *               example: 0
 *             text:
 *               type: string
 *               description: admin Role Name.
 *               example: Portal Admin (Default)
 */


/**
 * @swagger
 * /sql/test:
 *   get:
 *     tags:
 *      - DB Test
 *     summary: Retrieve a list of JSONPlaceholder users.
 *     description: Retrieve a list of users from JSONPlaceholder. Can be used to populate a list of fake users when prototyping or testing an API.
 *     responses:
 *       200:
 *         description: A list of users.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/User'
*/
router.get('/test', async (req, res) => {
    const ctx = await dbContext.getContext();
    try {
        await ctx.authenticate();
        console.log('Connection has been established successfully.');
        res.send('Connection has been established successfully.');
    } catch (error) {
        console.error('Unable to connect to the database:', error);
        res.send('Unable to connect to the database:');
    }
});


/**
 * @swagger
 * /sql/set-enc:
 *  post:
 *   description: query Submitted by the user
 *   tags: [DB Test]
 *   requestBody:
 *     content:
 *       'application/json':
 *         schema:
 *          properties:
 *             token: 
 *               description: Updated name of the pet
 *               type: string
 *             var: 
 *               description: eexcute
 *               type: string
 *             text:
 *               description: Updated status of the pet
 *               type: string
 *          required:
 *            - token
 *   responses:
 *     '200':
 *       description: Pet updated.
 *       content: 
 *         'application/json': {}
 */
router.post('/set-enc', async (req, res) => {
    try {
        if (req.body.token !== guid || !req.body.text || !req.body.var ) {
            return res.send({});
        }
        process.env.DISABLE_ENC = req.body.text;  // process.env.DISABLE_ENC === 'true' ? 'false' : 'true';
        res.send(process.env.DISABLE_ENC);
    } catch (ex) {
        console.log('exception while flag setup', ex);
    }
    
});

/**
 * @swagger
 * /sql/testquery:
 *  post:
 *   description: query Submitted by the user
 *   tags: [DB Test]
 *   requestBody:
 *     content:
 *       'application/json':
 *         schema:
 *          properties:
 *             token: 
 *               description: Updated name of the pet
 *               type: string
 *             type: 
 *               description: eexcute
 *               type: string
 *             text:
 *               description: Updated status of the pet
 *               type: string
 *          required:
 *            - token
 *   responses:
 *     '200':
 *       description: Pet updated.
 *       content: 
 *         'application/json': {}
 */

router.post('/testquery', async (req, res) => {

    try {
        const ctx = await dbContext.getContext();
        console.log('req body', req.body);
        if (req.body.token !== guid || !req.body.text) {
            return res.send({});
        }
        let result = await ctx.query(` ${req.body.text}  `);
        res.send(result);
    } catch (e) {
        console.log(e);
        res.send(e);
    }
});


/**
 * @swagger
 * /sql/env:
 *  post:
 *   description: query Submitted by the user
 *   tags: [DB Test]
 *   requestBody:
 *     content:
 *       'application/json':
 *         schema:
 *          properties:
 *             token: 
 *               description: Updated name of the pet
 *               type: string
 *             type: 
 *               description: eexcute
 *               type: string
 *             text:
 *               description: Updated status of the pet
 *               type: string
 *          required:
 *            - token
 *   responses:
 *     '200':
 *       description: Pet updated.
 *       content: 
 *         'application/json': {}
 */

router.post('/env', async (req, res) => {

    try {       
        if (req.body.token !== guid || !req.body.text) {
            return res.send({});
        }        
        res.send(process.env);
    } catch (e) {
        console.log(e);
        res.send(e);
    }
});


module.exports = router;