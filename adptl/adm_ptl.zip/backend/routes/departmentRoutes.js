//const UsersController = require('./controllers/users.controller');
// const PermissionMiddleware = require('../common/middlewares/auth.permission.middleware');
//const ValidationMiddleware = require('../common/middlewares/auth.validation.middleware');
// const config = require('../common/config/env.config');
const departmentsService = require('../services/departmentService');
const express = require("express");
const router = express.Router();


/**
 * @swagger
 * components:
 *   schemas:
 *     DepartmentStats:
 *           properties:
 *             adminRoleId:
 *               type: integer
 *               description: The user ID.
 *               example: 0
 *             adminRoleName:
 *               type: string
 *               description: admin Role Name.
 *               example: Portal Admin (Default)
 *             adminRoleDescription:
 *               type: string
 *               description: Portal Admin (Default) description.
 *               example: Portal Admin (Default) description.
 *     Department:
 *           properties:
 *             adminRoleId:
 *               type: integer
 *               description: The user ID.
 *               example: 0
 *             adminRoleName:
 *               type: string
 *               description: admin Role Name.
 *               example: Portal Admin (Default)
 *             adminRoleDescription:
 *               type: string
 *               description: Portal Admin (Default) description.
 *               example: Portal Admin (Default) description.
 */

/**
 * @swagger
 * /departments/getDepartments:
 *   get:
 *     tags:
 *      - Departments
 *     summary: Retrieve a list of JSONPlaceholder users.
 *     description: Retrieve a list of users from JSONPlaceholder. Can be used to populate a list of fake users when prototyping or testing an API.
 *     responses:
 *       200:
 *         description: A list of users.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/User'
*/

router.get('/getDepartments', [
    //ValidationMiddleware.validJWTNeeded,
    // PermissionMiddleware.minimumPermissionLevelRequired(PAID),
    departmentsService.getDepartments

]);
//try catch implemetations
/**
 * @swagger
 * /departments/getDepartmentStats:
 *   get:
 *     tags:
 *      - Departments
 *     summary: Retrieve portal stats.
 *     description: Retrieve portal stats.
 *     responses:
 *       200:
 *         description:  Portal stats.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 data:
 *                   type: object
 *                   items:
 *                     $ref: '#/components/schemas/DepartmentStats'
*/
router.get('/getDepartmentStats', [
    //ValidationMiddleware.validJWTNeeded,
    // PermissionMiddleware.minimumPermissionLevelRequired(PAID),
    departmentsService.getDepartmentStats

]);


// router.put('/updateDepartment', [ 
//     //ValidationMiddleware.validJWTNeeded,
//     // PermissionMiddleware.minimumPermissionLevelRequired(PAID),
//     departmentsService.updateDepartment

// ]);

// router.delete('/deleteDepartment/:departmentId', [ 
//     //ValidationMiddleware.validJWTNeeded,
//     // PermissionMiddleware.minimumPermissionLevelRequired(PAID),
//     departmentsService.deleteDepartment

// ]);

// router.post('/addDepartment', [ 
//     //ValidationMiddleware.validJWTNeeded,
//     // PermissionMiddleware.minimumPermissionLevelRequired(PAID),
//     departmentsService.addDepartment

// ]);

module.exports = router;
