
const userrolesService = require('../services/userRolesService');
const express = require("express");
const router = express.Router();
const { componentWrapper } = require("../common");

/**
 * @swagger
 * components:
 *   schemas:
 *     NewUser:
 *       type: object
 *       properties:
 *         name:
 *           type: string
 *           description: The user's name.
 *           example: Leanne Graham
 *     User:
 *       allOf:
 *         - type: object
 *           properties:
 *             id:
 *               type: integer
 *               description: The user ID.
 *               example: 0
 *             accessLevelId:
 *               type: integer
 *               description: The user ID.
 *               example: 0
 *             accessLevelName:
 *               type: integer
 *               description: The user ID.
 *               example: 0
 *         - $ref: '#/components/schemas/NewUser'
 *     AdminRole:
 *           properties:
 *             adminRoleId:
 *               type: integer
 *               description: The user ID.
 *               example: 0
 *             adminRoleName:
 *               type: string
 *               description: admin Role Name.
 *               example: Portal Admin (Default)
 *             adminRoleDescription:
 *               type: string
 *               description: Portal Admin (Default) description.
 *               example: Portal Admin (Default) description.
 *     Metadata:
 *           properties:
 *             about:
 *               type: string
 *               description: api call description.
 *               example: gets list of items
 *             rows:
 *               type: integer
 *               description: number of rows in result.
 *               example: 0
 *             responseStatus:
 *               type: integer
 *               description: http response status.
 *               example: 200, 500, 400 etc.
 *             responseTime:
 *               type: integer
 *               description: response time of api call in milliseconds.
 *               example: 2000.
 *     UpdateRolePermissionConfigurationResponse:
 *           properties:
 *             categoryIds:
 *               type: array
 *               items:
 *                  type: integer
 *               description: list of updated catgories ids.
 *               example: [ 1,2,]
 *             permissionIds:
 *               type: array
 *               items:
 *                  type: integer
 *               description:  list of updated role permissions ids.
 *               example: [ 1,2,] 
 *     PermissionCategory:
 *           properties:
 *             adminPermissionCategoryConfigurationId:
 *               type: integer
 *               description: admin permission category configuration id .
 *               example: 0
 *             adminPermissionCategoryId:
 *               type: integer
 *               description: permission category Id.
 *               example: 1 
 *             isActive:
 *               type: bool
 *               description: active status permission section.
 *               example: true
 *     RolePermission:
 *          properties:
 *             adminPermissionId:
 *               type: integer
 *               description: permission category Id.
 *               example: 1 
 *             isView:
 *               type: object
 *               description: view status of  permission.
 *               example: null
 *             isAdd:
 *               type: object
 *               description: adding status of permission.
 *               example: null
 *             isEdit:
 *               type: object
 *               description: editable status of permission.
 *               example: null
 *             isDelete:
 *               type: object
 *               description: delete status of permission.
 *               example: null
 *             isActive:
 *               type: bool
 *               description: active status permission section.
 *               example: false
 *             adminRoleTypePermissionConfigurationId:
 *               type: integer
 *               description: active status permission section.
 *               example: 0
 */


/**
 * @swagger
 * /userroles/getAdminRoles:
 *   get:
 *     tags:
 *      - UserRoles
 *     summary: Retrieve a list of admin Roles in the portal.
 *     description: Retrieve a list of admin Roles in the portal.
 *     responses:
 *       200:
 *         description: A list of admin Roles.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 metadata:
 *                    type: object
 *                    description: Details of Response .
 *                    example: 0
 *                    $ref: '#/components/schemas/Metadata'
 *                 resonse:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/AdminRole'
*/
router.get('/getAdminRoles', [    
    userrolesService.getAdminRoles
]);

/**
 * @swagger
 * /userroles/getAdminRoleTypes:
 *   get:
 *     tags:
 *      - UserRoles
 *     summary: Retrieve a list of admin Roles Types.
 *     description: Retrieve a list of admin Roles Types.
 *     responses:
 *       200:
 *         description: A list of admin Roles Types.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 metadata:
 *                    type: object
 *                    description: Details of Response .
 *                    example: 0
 *                    $ref: '#/components/schemas/Metadata'
 *                 resonse:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/AdminRole'
*/

router.get('/getAdminRoleTypes', [    
    userrolesService.getAdminRoleTypes,  componentWrapper  
]);

// router.get('/getAdminRoleUsers/:adminRoleId/:adminRoleTypId', [
//     userrolesService.getAdminRoleUsers
// ]);

// router.get('/getAdminRolePermissions/:adminRoleId/:adminRoleTypId', [  
//     userrolesService.getAdminRolesPermissions
// ]);

/**
 * @swagger
 * /userroles/getAdminRoleTypePermissions/{adminRoleTypeId}:
 *   get:
 *     tags:
 *      - UserRoles
 *     summary: Retrieve a list of admin permissions assigned to a given admin role type id in the portal.
 *     description: Retrieve a list of admin permissions assigned to a given admin role type id in the portal.
 *     responses:
 *       200:
 *         description: A list of admin permissions assigned to a given admin role type id.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 metadata:
 *                    type: object
 *                    description: Details of Response .
 *                    example: 0
 *                    $ref: '#/components/schemas/Metadata'
 *                 resonse:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/AdminRole'
 *     parameters:
 *        - in: path
 *          name: adminRoleTypeId
 *          description: ID of pet that needs to be updated
 *          type: integer
*/
router.get('/getAdminRoleTypePermissions/:adminRoleTypeId', [    
    userrolesService.getAdminRoleTypePermissions
]);

/**
 * @swagger
 * /userroles/getAdminRoleTypePermissionConfiguration/{adminRoleTypeId}:
 *   get:
 *     tags:
 *      - UserRoles
 *     summary: Retrieve a list of admin permissions assigned to a given admin role type from configuration in the portal.
 *     description: Retrieve a list of admin permissions assigned to a given admin role type from configuration in the portal.
 *     responses:
 *       200:
 *         description: A list of admin permissions assigned to a given admin role type from configuration in the portal.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 metadata:
 *                    type: object
 *                    description: Details of Response .
 *                    example: 0
 *                    $ref: '#/components/schemas/Metadata'
 *                 resonse:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/AdminRole'
 *     parameters:
 *        - in: path
 *          name: adminRoleTypeId
 *          description: ID of pet that needs to be updated
 *          type: integer
*/
router.get('/getAdminRoleTypePermissionConfiguration/:adminRoleTypeId', [    
    userrolesService.getAdminRoleTypePermissionConfiguration
]);



// router.put('/updateUserRole', [ 
//     //ValidationMiddleware.validJWTNeeded,
//     // PermissionMiddleware.minimumPermissionLevelRequired(PAID),
//     userrolesService.updateUserRole

// ]);

// router.delete('/deleteUserRole/:accessLevelId', [ 
//     //ValidationMiddleware.validJWTNeeded,
//     // PermissionMiddleware.minimumPermissionLevelRequired(PAID),
//     userrolesService.deleteUserRole

// ]);

router.post('/addUserRole', [ 
    //ValidationMiddleware.validJWTNeeded,
    // PermissionMiddleware.minimumPermissionLevelRequired(PAID),
    userrolesService.addAdminRole
]);


/**
 * @swagger
 * /userroles/updateAdminRoleTypePermissions/{adminRoleTypeId}:
 *   put:
 *     tags:
 *      - UserRoles
 *     summary: Retrieve a list of admin permissions assigned to a given admin role type id in the portal.
 *     description: Retrieve a list of admin permissions assigned to a given admin role type id in the portal.
 *     responses:
 *       200:
 *         description: A list of updated category ids and admin permissions ids.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 metadata:
 *                    type: object
 *                    description: Details of Response .
 *                    example: 0
 *                    $ref: '#/components/schemas/Metadata'
 *                 resonse:
 *                   type: object
 *                   description: list of updated records ids
 *                   $ref: '#/components/schemas/UpdateRolePermissionConfigurationResponse'
 *     parameters:
 *        - in: path
 *          name: adminRoleTypeId
 *          description: ID of pet that needs to be updated
 *          type: integer
 *        - in: body
 *          name: Permissions with Categories
 *          description:
 *          schema:
 *            type: object
 *            required:
 *              - adminRoleTypeId
 *            properties:
 *              adminRoleTypeId:
 *                type: integer
 *              categories:
 *                type: array
 *                items:
 *                 $ref: '#/components/schemas/PermissionCategory'
 *              permissions:
 *                type: array
 *                items:
 *                 $ref: '#/components/schemas/RolePermission'
 * 
 * 
*/

router.put('/updateAdminRoleTypePermissions/:adminRoleTypId', [ 
    //ValidationMiddleware.validJWTNeeded,
    // PermissionMiddleware.minimumPermissionLevelRequired(PAID),
    userrolesService.updateAdminRoleTypePermissionConfiguration
]);


module.exports = router;
