
const { Op, QueryTypes } = require("sequelize");
// const { DefaultAzureCredential } = require("@azure/identity");
const Sequelize = require('sequelize');
const errorLogger = require('../errorHandler');
const { logInfo, logError, logger } = require('../logger');
var dbContext = require("./dbcontext");
const { componentWrapper, apiResponse } = require("../common");
const { JSON_CONFIG_FILENAME } = require("tslint/lib/configuration");
const {encryptJSON, encryptResponse} = require('../encrypt-decrypt');

exports.getDepartments = async (req, res) => {

    var options = {};
    options.query = `
                    select ds.department_id as departmentId, 
                    ds.department_code as departmentCode, 
                    ds.department_name departmentName, 
                    ds.department_name departmentDescription,
                    ds.department_prefix departmentPrefix, 
                    ds.created_date createdDate  
                    from Departments ds         
    `;
    req.options = options;
    let result = apiResponse;
    console.log('empty result', result);
    try {
        // logError({ level: 'error_ak_try_block', message: 'try block',  hostname: req.hostname, port: req.port, username: 'ankam.bollimuntha@cdw.com', req: (req.protocol + "://" + req.get('host') + req.originalUrl) })
        result = await componentWrapper(req, res);       
        //logError({ level: 'error_ak_try_block_end', message: result,  hostname: req.hostname, port: req.port, username: 'ankam.bollimuntha@cdw.com', req: (req.protocol + "://" + req.get('host') + req.originalUrl) })

    } catch (ex) {
        logError({ level: 'error', message: ex.message,  hostname: req.hostname, port: req.port, username: 'ankam.bollimuntha@cdw.com', req: (req.protocol + "://" + req.get('host') + req.originalUrl) })
        
        // res.send(ex);
    } finally {
        //logInfo();
        console.log('finally block: total records' , result.response ? result.response.length: 0);
        // logError({ level: 'error', message: 'error_ak_try_block_end finally' + JSON.stringify(result),  hostname: req.hostname, port: req.port, username: 'ankam.bollimuntha@cdw.com', req: (req.protocol + "://" + req.get('host') + req.originalUrl) })

        if(result.metadata.responseStatus != 500){
        logger.info('get detpartments api', { level: 'info', message: 'get detpartments api', 
        hostname: req.hostname, port: req.port, req: (req.protocol + "://" + req.get('host') + req.originalUrl) })    
        }   
        res.status(result.metadata.responseStatus);        
        //res.json(result);  
        //logError({ level: 'error', message: 'finally' + encryptResponse(result),  hostname: req.hostname, port: req.port, username: 'ankam.bollimuntha@cdw.com', req: (req.protocol + "://" + req.get('host') + req.originalUrl) })
        res.send(encryptResponse(result));   
        // logError({ level: 'error', message: 'sending result',  hostname: req.hostname, port: req.port, username: 'ankam.bollimuntha@cdw.com', req: (req.protocol + "://" + req.get('host') + req.originalUrl) })

    };

}

// exports.addDepartment = async (req, res) => {


//     contex.getContext().departments.create({
//         departmentName: req.body.departmentName,
//         departmentPrefix: req.body.departmentPrefix,
//         departmentDescription: req.body.departmentDescription,
//         isActive: true
//     }).then((result) => {
//         res.send(encryptResponse(result));
//     });
// };
// exports.deleteDepartment = async (req, res) => {
//     contex.getContext().departments.update(
//         { isActive: false },
//         { where: { departmentId: req.params.departmentId } }
//     )
//         .then(result => {
//             res.send(encryptResponse(result));
//         }
//         )
//         .error(err => {
//             res.staus(500).send(err);
//         }
//         )
// };

// exports.updateDepartment = async (req, res) => {
//     contex.getContext().departments.update(
//         req.body,
//         { where: { departmentId: req.body.departmentId } }
//     ).then(result => {
//             res.send(encryptResponse(result));
//         }
//         )
//         .error(err => {
//             res.staus(500).send(err);
//         }
//         )
// };

exports.getDepartmentStats = async (req, res) => {

    var options = {};
    options.query = `
            select count(dept.department_id) departments, count(ad_user.department_id) departmentAdmins,
            count(us_group.user_group_id) groups, count(ad_user.user_group_id) groupAdmins,
            count(us.user_id) users, count(case when us.is_active=1 then '*' else NULL end) activeUsers
            from Departments dept
            left join admin_users ad_user on dept.department_id = ad_user.department_id
            full outer join user_groups us_group on ad_user.user_group_id = us_group.user_group_id
            full outer join users us on ad_user.user_id = us.user_id`;
    req.options = options;
    let result = {};
    try {
        result = await componentWrapper(req, res);
    } catch (ex) {
        // res.send(ex);
    } finally {
        res.status(result.metadata.responseStatus);
        result.response = result.response[0];
       // res.json(result);
        res.send(encryptResponse(result));
    }
}