const powerbiEmbedService = require('./powerbiEmbedService');
const reportService = require('./reportService');

exports.getEmbebToken = async (req, res) => {
    
   
    // let params = await reportService.getReportParams(req.params.reportId);    
    console.log('******************************************************************************');
    params = req.body;
    console.log(params);
    powerbiEmbedService.getEmbedInfo(params.pbi_workspace_id, params.pbi_report_id, params.reportFilters).then((result) => {
     res.send(result);
    }); 
};