
const { Op, QueryTypes } = require("sequelize");
const adminRolePermissions = require("../models/adminRolePermissions");
const Sequelize = require('sequelize');
// const { DefaultAzureCredential } = require("@azure/identity");
var dbContext = require("./dbcontext");
const { logInfo, logError, logger } = require('../logger');
const {apiResponse} = require("../common")
const { performance } = require('perf_hooks');
const {encryptJSON, encryptResponse} = require('../encrypt-decrypt');

exports.getUsers = async (req, res) => {
    let startTime = performance.now();
    let response = {};
    let result = apiResponse;
    try {
        queryParams = {};
        queryParams.query = `
                                SELECT 
                                usr.user_id userId,
                                dept.department_name adminRole,
                                usr.first_name + ' '+ usr.last_name name,
                                usr.coworker_id coworkerId,
                                usr.department_id departmentId,
                                dept.department_name departmentName,
                                count(gpm.user_id) accessibleReports,
                                count(gpm.user_id) groups,   
	                            act_type.created_date lastActivityDate
                                FROM [dbo].[users] usr 
                                left join  group_members gpm on usr.user_id = gpm.user_id
                                left join Departments dept on usr.department_id = dept.department_id
                                left join User_action_types act_type on act_type.user_action_type_id = (SELECT  top 1 act_type.user_action_type_id
                                         FROM   User_actions usr_act  
                                         join User_action_types act_type on usr_act.user_action_type_id = act_type.user_action_type_id
                                         where usr_act.user_id = usr.user_id order by usr_act.created_date desc )
                                group by usr.user_id ,
                                usr.first_name + ' '+ usr.last_name,
                                usr.coworker_id ,
                                usr.department_id ,
                                dept.department_name,
	                            act_type.created_date        
                            `;
        response = await dbContext.executeSql(queryParams)
        result.metadata.rows = response.result[1];
        result.metadata.responseStatus = response.status;
        result.response = response.result[0];
        // result.metadata.rows = response.result.rowsAffected;
        result.metadata.responseStatus = response.status;      
    } catch (ex) {
        // res.send(ex);
    } finally {
        // logger.info(response.log);
        result.metadata.responseTime = performance.now() - startTime;
        res.status(response.status || result.metadata.responseStatus);
       //res.json(result);
       res.send(encryptResponse(result));
    }
};

