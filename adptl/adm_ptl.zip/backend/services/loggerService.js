const { QueryTypes } = require("sequelize");
var dbContext = require("./dbcontext");
const winston = require('winston');

const logger = winston.createLogger({
    level: winston.config.npm.levels,
    format: winston.format.json(),
    defaultMeta: { service: 'user-service' },
    transports: [
        new winston.transports.File({ filename: 'logs/loggerservice.log', level: 'error' }),
        new winston.transports.File({ filename: 'logs/loggerserviceInfo.log', level: 'info' }),
    ],
});

if (process.env.NODE_ENV !== 'production') {
    logger.add(new winston.transports.Console({
        format: winston.format.simple(),
    }));
}

exports.insertLog = async (req, res) => {
    try {
        logger.info('Inside write log service');
        let response = {};
        let { userId, userName, logLevel, logDescription } = req.body;
        let isActive = true;
        // if (logDescription) {
        //     logDescription = logDescription.replace(/'/g, "\\'")
        // }
        const ctx = await dbContext.getContext();
        await ctx.query(`
        INSERT INTO logs (user_id, username, log_level, log_description, is_Active) VALUES ('${userId}', '${userName}','${logLevel}', '${logDescription}','${isActive}')       
`, { type: QueryTypes.INSERT });
        logger.info('Insert success in log service');
        response["status"] = 200;
        res.send(response);
    } catch (ex) {
        logger.error('Insert failure in log service' + messageFormatter(ex));
        response["status"] = 500;
        res.send(response);
    }
};

exports.insertBackendLog = async (userId, userName, logLevel, logDescription, req) => {
    try {
        logger.info('Inside Backend log service');
        let isActive = true;
        const ctx = await dbContext.getContext();
        // if (logDescription) {
        //     logDescription = logDescription.replace(/'/g, "\\'")
        // }
        let query = `
        INSERT INTO logs (user_id, username, log_level, log_description, is_Active, request) VALUES ('${userId}', '${userName}','${logLevel}', '${logDescription}','${isActive}', '${req}')       
        `
        ctx.query(query, { type: QueryTypes.INSERT });
        logger.info('Insert success in Backend log service');
    } catch (ex) {
        logger.error('Insert failure in Backend log service' + messageFormatter(ex));
    }
};

function messageFormatter(msg) {
    try {
        return JSON.stringify(msg);
    }
    catch {
        return msg;
    }
}

