const sequelize = require('sequelize');
const azureIdentity = require("@azure/identity");
const {logError} = require('../logger');
// const { DefaultAzureCredential } = require("@azure/identity");
const { exec } = require('child_process');


const config = {
  database: process.env.DB, // AZURE_SQL_DB,
  host: process.env.DB_SERVER, // AZURE_SQL_SERVER,
  dialect: 'mssql',
  encrypt: true,
  logging: process.env.NODE_ENV === 'production' ? false : console.log, // winston.debug
  dialectOptions: {
    authentication: {
      type: 'azure-active-directory-access-token',
      options: {
        token: process.env.dbaccessToken,
      },
    }
  }
};

seqlContext = new sequelize('AmnetDB', 'sa', 'Root@123', {
  host: 'localhost',
  dialect: 'mssql',
  dialectOptions: {
    options: {
      encrypt: true,
    }
  }
});
let initModels = require("../models/init-models");
let dbmodels = initModels(seqlContext);
// let dbmodels = null;

function isTokenExpired(token) {
  const payloadBase64 = token.split('.')[1];
  const decodedJson = Buffer.from(payloadBase64, 'base64').toString();
  const decoded = JSON.parse(decodedJson)
  const exp = decoded.exp;
  console.log(exp);
  const expired = (Date.now() >= exp * 1000)
  console.log("token epires in  min", Math.floor(Math.abs(Date.now() - exp * 1000) / 1000 / 60));
  return expired
}

async function getContext() {
  try {
    // if (!process.env.dbaccessToken || isTokenExpired(process.env.dbaccessToken) || !seqlContext) {
    //   // if(isTokenExpired(process.env.dbaccessToken){
    //   //   // 
    //   // }      
    //   const credential = new DefaultAzureCredential();
      
    //   let dbaccessToken = await credential.getToken('https://database.windows.net/.default');
    //   process.env.dbaccessToken = dbaccessToken.token;
    //   // console.log(dbaccessToken.token)
    //   // console.log('token credential ', credential);
    //   process.env.dbaccessTokenExpiry = dbaccessToken.token.expiresOnTimestamp;
    //   config.dialectOptions.authentication.options.token = process.env.dbaccessToken
    //   seqlContext = new sequelize(config);
    //   var initModels = require("../models/init-models");
    //   dbmodels = initModels(seqlContext);
    // }
    
  } catch (ex) {
    console.log("failed while fetching access token ", ex.message);    
    logError({ level: 'error_ak', message: ex.message,  hostname: '', port: '',
     username: 'ankam.bollimuntha@cdw.com', 
    req: '' })
    throw ex;
  }

  return seqlContext;
}

const executeSql = async (sqlExp) => {
  let response = {};
  response.logInfo = {};
  let result = '';
  try {
    const ctx = await getContext();
    if (sqlExp.queryParams) {
      //todo: map params to query
      result = await ctx.query(sqlExp.query, { replacements: sqlExp.queryParams });
    } else {
      result = await ctx.query(sqlExp.query);
    }
    response.status = 200;
    response.result = result;
    response.logInfo.status = 200;
  } catch (err) {
    logError({ level: 'error', message: err.message,  hostname: '', port: '',
    username: 'ankam.bollimuntha@cdw.com', req: '' })
    response.logInfo.level = "error";
    response.logInfo.status = 500;
    // response.logInfo.message = logInfo.message + " : " + err.message;
    response.status = 500;
    response.result = err.message;
    throw err;
  } finally {
    return response;
  }

}

async function getModels() {
  try {
    if (!dbmodels) {
      await getContext();
      return dbmodels;
    }
    seqlContext = new sequelize(config);
    var initModels = require("../models/init-models");
    dbmodels = initModels(sequelize);
    // console.log(dbmodels);
  } catch (ex) {
    console.log("failed while fetching access token ");
    // logError(ex); 
  }

  return dbmodels;
}

module.exports = {
  getContext,
  executeSql,
  getModels,
  dbmodels
}

