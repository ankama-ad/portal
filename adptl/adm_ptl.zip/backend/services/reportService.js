
const { Op, QueryTypes } = require("sequelize");
const adminRolePermissions = require("../models/adminRolePermissions");
const Sequelize = require('sequelize');
// const { DefaultAzureCredential } = require("@azure/identity");
var dbContext = require("./dbcontext");
const { logInfo, logError, logger } = require('../logger');
const {apiResponse} = require("../common")
const { performance } = require('perf_hooks');
const {encryptJSON, encryptResponse} = require('../encrypt-decrypt');

//var ReportFilters = contex.getContext().reportFilters;
// const { Op } = require("sequelize");


// const reportService = require('../services/reportService');
// // const graphService =  require('../services/graphService');

// exports.getReports = async (req, res) => {    
//      // join  report 
//      contex.getContext().reports.findAll({
//         where: {   isActive:{ [Op.eq]: true } }
//     }).then((result) => {
//         res.status(200).send(result);
//     });
// };

// exports.getUserReports = async (req, res) => {          
  
//     req.params.email = "ajay@powerbiaxes.onmicrosoft.com";    
//     try {
//         let user = await contex.getContext().users.findOne({
//             where: {   isActive:{ [Op.eq]: true }, username: { [Op.eq]: req.params.email } }
//         });
//         //var ReportAccess = require('../models/ReportAccess');
//         console.log('user obj', user)
//         // join  report 
//         let reports = await contex.getContext().reportAccess.findAll({
    
//             include: [            
//                 {
//                   model: contex.getContext().reports,
//                   as: 'report',
//                   require: true   
//                 }
//               ],       
//             where: { isActive:{ [Op.eq]: true },  [Op.or]: [{userId:  user.userId}]   }
//         }).then((reports) => {
//             console.log('reports  ', reports);
//             let reportsList = reports.map(c => c.report);
//             res.status(200).send(reportsList);
//         });
                              
//       } catch(e){
//         console.log(e);
//       }   
// };

// exports.getWorkspaceByReportId = async (reportId) => {
//     let keys = Object.keys(model);
//     let report = await contex.getContext().reports.findAll({
//         where: {
//             reportId:reportId
//     }
//     }); 
//     return report.workspaceId;
// };

// exports.getReportParams = async (reportId) => {
   
//     // join  report 
//     let report = await contex.getContext().reports.findOne({
//         where: {   id:{ [Op.eq]: reportId } },
//         include: [{ model: contex.getContext().reportFilters, as: 'reportFilters'}]
//     });    
//     return report;
// };

exports.getReports = async (req, res) => {
    let startTime = performance.now();
    let response = {};
    let result = apiResponse;
    try {
        queryParams = {};
        queryParams.query = `SELECT * from reports`;
        response = await dbContext.executeSql(queryParams)
        result.metadata.rows = response.result[1];
        result.metadata.responseStatus = response.status;
        result.response = response.result[0];
        // result.metadata.rows = response.result.rowsAffected;
        result.metadata.responseStatus = response.status;      
    } catch (ex) {
        // res.send(ex);
    } finally {
        // logger.info(response.log);
        result.metadata.responseTime = performance.now() - startTime;
        res.status(response.status || result.metadata.responseStatus);
       //res.json(result);
       res.send(encryptResponse(result));
    }
};
