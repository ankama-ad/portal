#!/bin/bash

curl https://packages.microsoft.com/keys/microsoft.asc | apt-key add -

#Debian 10
curl https://packages.microsoft.com/config/debian/10/prod.list > /etc/apt/sources.list.d/mssql-release.list

apt-get update
echo '********************  installing msodbcsql17 **********************************'
ACCEPT_EULA=Y apt-get install -y msodbcsql17
# optional: for bcp and sqlcmd
echo '********************  installing  mssql-tools **********************************'
ACCEPT_EULA=Y apt-get install -y mssql-tools

echo '********************  setting path **********************************'
echo 'export PATH="$PATH:/opt/mssql-tools/bin"' >> ~/.bashrc
source ~/.bashrc

# optional: for unixODBC development headers
echo '********************  installing unixodbc-dev **********************************'
apt-get install -y unixodbc-dev

# optional: kerberos library for debian-slim distributions
echo '********************  installing libgssapi-krb5-2 **********************************'
apt-get install -y libgssapi-krb5-2