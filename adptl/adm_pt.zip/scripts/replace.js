let fs = require('fs')
let filepath = './backend/views/env.js'

let isProcessCompleted = false;

function verifyProcess() {
  console.log("waiting for template parse....");
  if (!isProcessCompleted) {//we want it to match
    setTimeout(verifyProcess, 50);//wait 50 millisecnds then recheck
    return;
  }
}

fs.readFile(filepath, 'utf8', function (err, data) {
  if (err) {
    isProcessCompleted = true;
    console.log("Failed in template reading  ......");
    return console.log(err);
  }
  let result = data.replace(/http:\/\/localhost:8080\/api\//g, process.env.BASE_API_URL);
  fs.writeFile(filepath, result, 'utf8', function (err) {
    isProcessCompleted = true;    
    if (err) {
      console.log("Failed in template overwrite ......");
      return console.log(err);
    }
    console.log("Just done ......");
  });
});

verifyProcess();