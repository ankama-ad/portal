import { TestRequest } from "@angular/common/http/testing";

export const environment = {
  production: TestRequest,
   enableLogger:false,
  baseApiUrl: 'https://enterprisereportingdev.azurewebsites.net/api/',
  appId: '6878a486-4dea-4baa-9713-8f99f9d63052',
  REDIRECT_URL: 'https://enterprisereportingdev.azurewebsites.net/login?returnTo=',
  SIGNIN_URL: '/signin?returnTo=',
  ENC_KEY: "abc123abc"
};
