import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ReportManagementRoutingModule } from './report-management-routing.module';
import { ReportManagementComponent } from './report-management.component';


@NgModule({
  declarations: [
    ReportManagementComponent
  ],
  imports: [
    CommonModule,
    ReportManagementRoutingModule
  ]
})
export class ReportManagementModule { }
