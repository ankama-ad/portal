import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BaseAPIService } from '../baseAPIService';


@Injectable({
  providedIn: 'root'
})
export class UsersService extends BaseAPIService {

  baseApiUrl = ''; // `${environment.baseApiUrl}users/`;
  headers: HttpHeaders;
  constructor(public http: HttpClient) {
    super(http);    
    this.baseApiUrl = `${this.apiUrl}users/`;
    this.headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*'
    });
  }

  getUsers(): Observable<any[]> {
    return this.http.get<any[]>(this.baseApiUrl + "getUsers");
  }

}