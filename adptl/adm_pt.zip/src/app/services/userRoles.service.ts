import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

import { userRoles } from '../views/configurations/departments/models/userRoles';
import { BaseAPIService } from '../baseAPIService';


@Injectable({
  providedIn: 'root'
})
export class UserRolesService extends BaseAPIService { 

  baseApiUrl= '';
  headers: HttpHeaders;
  constructor(public http: HttpClient) {
    super(http);    
    this.baseApiUrl = `${this.apiUrl}userRoles/`;
    this.headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*'
    });

  }

  getUserRoles(): Observable<userRoles[]> {
    return this.http.get<userRoles[]>(this.baseApiUrl + "getUserRoles");
  }

  getAdminRoleUsers(model: any): Observable<any[]> {
    return this.http.get<any[]>(this.baseApiUrl + `getAdminRoleUsers/${model.adminRoleId}/${model.adminRoleTypeId}`);    
  }

  getAdminRoleTypePermissions(adminRoleTypeId: any): Observable<any[]> {
    return this.http.get<any[]>(this.baseApiUrl + `getAdminRoleTypePermissions/${adminRoleTypeId}`);    
  }

  getAdminRoleTypePermissionConfiguration(adminRoleTypeId: any): Observable<any[]> {
    return this.http.get<any[]>(this.baseApiUrl + `getAdminRoleTypePermissionConfiguration/${adminRoleTypeId}`);    
  }

  updateAdminRoleTypePermissions(model: any): Observable<any> {
    return this.http.put<any>(this.baseApiUrl + `updateAdminRoleTypePermissions/${model.adminRoleTypeId}`, model);
  }

  getAdminRolePermissions(model: any): Observable<any[]> {
    return this.http.get<any[]>(this.baseApiUrl + `getAdminRolePermissions/${model.adminRoleId}/${model.adminRoleTypeId}`);    
  }
  
  getAdminRoles(): Observable<any> {
    return this.http.get<any>(this.baseApiUrl + "getAdminRoles");
  }

  getAdminRoleTypess(): Observable<any> {
    return this.http.get<any>(this.baseApiUrl + "getAdminRoleTypes");
  }
  

  addUserRole(model: any): Observable<any> {
    return this.http.post<any>(this.baseApiUrl + "addUserRole", model);
  }  

  updateUserRole(model: userRoles): Observable<any> {
    return this.http.put<any>(this.baseApiUrl + "updateUserRole", model);
  }

  deleteUserRole(model: userRoles): Observable<any> {
    return this.http.delete<any>(this.baseApiUrl + `deleteUserRole/ ${model.accessLevelId}`);
  }

}