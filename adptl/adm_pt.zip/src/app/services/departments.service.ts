import { Injectable } from '@angular/core';
import { HttpClient, HttpContext, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Department } from '../views/configurations/departments/models/department';
import { CACHE_REQUEST } from '../../caching-interceptor.service';
import { BaseAPIService } from '../baseAPIService';

@Injectable({
  providedIn: 'root'
})
export class DepartmentsService extends BaseAPIService {

  baseApiUrl:string = '' // `${environment.baseApiUrl}departments/`;
  headers: HttpHeaders;
  constructor(public http: HttpClient) {
    super(http);    
    this.baseApiUrl = `${this.apiUrl}departments/`;
    this.headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*'
    });

   }

   getDepartments(): Observable<any>{  
    console.log('app rul',this.apiUrl);
    return this.http.get<any>( this.baseApiUrl + "getDepartments");
   }

   getDepartmentStats(): Observable<any>{
    return this.http.get<any>( this.baseApiUrl + "getDepartmentStats");
   }

   addDepartment(model: Department): Observable<any>{
    return this.http.post<any>( this.baseApiUrl + "addDepartment", model);
   }

   updateDepartment(model: Department): Observable<any>{
    return this.http.put<any>( this.baseApiUrl + "updateDepartment", model);
   }

   deleteDepartment(model: Department): Observable<any>{
    return this.http.delete<any>( this.baseApiUrl + `deleteDepartment/${model.departmentId}`);
   }

}
