import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FeedbackManagementRoutingModule } from './feedback-management-routing.module';
import { FeedbackManagementComponent } from './feedback-management.component';


@NgModule({
  declarations: [
    FeedbackManagementComponent
  ],
  imports: [
    CommonModule,
    FeedbackManagementRoutingModule
  ]
})
export class FeedbackManagementModule { }
