import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feedback-management',
  templateUrl: './feedback-management.component.html',
  styleUrls: ['./feedback-management.component.scss']
})
export class FeedbackManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
