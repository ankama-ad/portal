import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ReportAccessRoutingModule } from './report-access-routing.module';
import { ReportAccessComponent } from './report-access.component';


@NgModule({
  declarations: [
    ReportAccessComponent
  ],
  imports: [
    CommonModule,
    ReportAccessRoutingModule
  ]
})
export class ReportAccessModule { }
