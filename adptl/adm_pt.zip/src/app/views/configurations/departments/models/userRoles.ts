export interface userRoles {
    accessLevelId: number,
    accessLevelName:string,
    description:string,
    isActive: boolean,  
    canView: boolean,
    canApprove: boolean,  
    canShare: boolean, 
    canSubscribe: boolean, 

  }