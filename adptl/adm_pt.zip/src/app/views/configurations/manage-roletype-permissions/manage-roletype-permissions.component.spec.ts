import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageRoletypePermissionsComponent } from './manage-roletype-permissions.component';

describe('ManageRoletypePermissionsComponent', () => {
  let component: ManageRoletypePermissionsComponent;
  let fixture: ComponentFixture<ManageRoletypePermissionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManageRoletypePermissionsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageRoletypePermissionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
