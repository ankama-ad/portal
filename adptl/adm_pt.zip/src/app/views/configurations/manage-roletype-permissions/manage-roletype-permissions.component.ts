import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { AfterViewInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserRolesService } from '../../../services/userRoles.service';
import { userRoles } from '../departments/models/userRoles';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';

const ALPHA_NUMERIC_REGEX = /^[a-zA-Z\. \( \) \-]+$/;
const ALPHA_NUMERIC_VALIDATION_ERROR = { alphaNumericError: 'only alpha numeric values are allowed' }

@Component({
  selector: 'app-manage-roletype-permissions',
  templateUrl: './manage-roletype-permissions.component.html',
  styleUrls: ['./manage-roletype-permissions.component.scss']
})
export class ManageRoletypePermissionsComponent implements OnInit {
  isEdit = false;
  isConfig = false;
  model = <any>{};
  userRoleTypes: any[] = [];
  userRolesForm: FormGroup;
  permissions: Array<any>
  isValid = false;
  roleTypeName: string;
  roleTypeId: string;
  constructor(private route: ActivatedRoute, private router: Router, private userRolesService: UserRolesService, private dialog: MatDialog, private _snackBar: MatSnackBar) {
    if (this.router.getCurrentNavigation().extras.state) {
      this.model = <any>this.router.getCurrentNavigation().extras.state;
      console.log('****role type ******', this.model)
    }

    this.route.paramMap.subscribe(paramMap => {
      this.roleTypeId = paramMap.get('roleTypeId');
      this.roleTypeName = paramMap.get('roleTypeName');
      this.loadRoleTypePermissions();
    })
  }

  ngOnInit(): void {
    // this.createForm();
    // this.loadUserRoleTypes();
    // this.loadRoleTypePermissions();
  }

  loadRoleTypePermissions(): void {

    this.userRolesService.getAdminRoleTypePermissionConfiguration(this.roleTypeId)
      .subscribe((res: any) => {
        if (res.metadata.responseStatus === 200 && res.metadata.rows != 0) {
          this.permissions = res.response;
        }
      })
  }
  toArray(arr: any) {
    if (arr) {
      return [arr];
    }
  }
  createForm(): void {
    this.userRolesForm = new FormGroup({
      isDefaultRole: new FormControl('')
    });
    // if(this.model.accessLevelId){
    //   // this.userRolesForm.patchValue(this.model);
    // }
  }

  public hasError = (controlName: string, errorName: string) => {
    return this.userRolesForm.get(controlName).hasError(errorName);
  }

  setPermission(event: any, item: any, key: string) {
    console.log(event);
    item[key] = !!event.val;
  }
  updateadminRoleTypePermission() {
    let permissionAndCategory = this.getflattenedPermissionfromTreeNodes();
    let roleWithPermission = {
      adminRoleTypeId: this.roleTypeId,
      categories: permissionAndCategory.parentNodes,
      permissions: permissionAndCategory.flattenedCollection
    };
    console.log(permissionAndCategory);
    this.userRolesService.updateAdminRoleTypePermissions(roleWithPermission).subscribe(res => {
      this.router.navigate(['/settings/manageuserroles'], { state: { activeTabIndex: 2 } });
      this._snackBar.open('Roles permissions updated successfully', '', {
        horizontalPosition: 'center',
        verticalPosition: 'top',
        duration: 3000,
      });
    },
      err => {
        this._snackBar.open('Error in saving Roles Permissions', '', {
          horizontalPosition: 'center',
          verticalPosition: 'top',
          duration: 3000,
        });
      }
    );
  }

  setupChildNodes(item, checkStatus) {
    console.log(item);
    if (item && item.children && item.children.length) {
      let bfs = function (tree, key) {
        if (!tree[key] || tree[key].length === 0) {
          tree.isActive = checkStatus;
          return;
        }
        for (var i = 0; i < tree[key].length; i++) {
          var child = tree[key][i];
          bfs(child, key);
        }
        return;
      };

      item.children.forEach(c => {
        bfs(c, "children");
      })
    } else {
      // verify if all nodes disabled
      console.log('child', item);
      let flattenedCollection = null;
      let parentNodes = [];
      let isSetup = false;
      let bfs = function (tree, key, collection) {

        if (isSetup) {
          return;
        }
        if ((!tree[key] || tree[key].length === 0) && collection && tree.categoryId === item.categoryId) {
          collection.push(tree);
          return;
        }
        if (tree.categoryId === item.categoryId && tree.children && tree.children.length) {
          collection = [];
          // iterate in childer nodes
          tree.children.forEach(c => {
            bfs(c, "children", collection);
          })
          // 
          let isAllfalse = collection.some(c => c.isActive);
          if (!isAllfalse) {
            tree.isActive = false;
          } else {
            tree.isActive = true;
          }
          isSetup = true;
          return;
        }
        for (var i = 0; i < tree[key].length; i++) {
          var child = tree[key][i];
          bfs(child, key, collection);
        }
        return;
      };
      this.permissions.forEach(c => {
        bfs(c, "children", flattenedCollection);
      })
    }
  }

  cancel() {
    this.router.navigate(['/settings/manageuserroles'], { state: { activeTabIndex: 0 } });
    //this.router.navigate(['/settings/departments']);
  }


  getflattenedPermissionfromTreeNodes() {
    let flattenedCollection = [];
    let parentNodes = [];
    let bfs = function (tree, key, collection) {
      if (!tree[key] || tree[key].length === 0) {
        collection.push(tree);
        return;
      }
      parentNodes.push({
        adminPermissionCategoryConfigurationId: tree.adminPermissionCategoryConfigurationId,
        adminPermissionCategoryId: tree.categoryId,
        isActive: tree.isActive
      });
      for (var i = 0; i < tree[key].length; i++) {
        var child = tree[key][i];
        bfs(child, key, collection);
      }
      return;
    };
    this.permissions.forEach(c => {
      bfs(c, "children", flattenedCollection);
    })

    // enable parent if child is enabled


    return { flattenedCollection, parentNodes };
  }


  alphaNumericValidator(control: FormControl): ValidationErrors | null {
    return ALPHA_NUMERIC_REGEX.test(control.value) ? null : ALPHA_NUMERIC_VALIDATION_ERROR;
  }


}
