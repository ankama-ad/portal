import { Component, ElementRef, OnInit, Pipe, PipeTransform, Renderer2, ViewChild } from '@angular/core'
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, Route, Router } from '@angular/router'
import * as Tableau from 'tableau-api-js';



@Component({
  selector: 'app-display-report',
  templateUrl: './display-report.component.html',
  styleUrls: ['./display-report.component.scss'],
})
export class DisplayReportComponent implements OnInit {
  @ViewChild('reportContent') reportContent: ElementRef; 
  reportId = 0;
  report_content = '';
  reportParams = { id: 0, report_type: 1, report_content:'', report_link:'', report_name: '' };
  constructor(private router: Router, private renderer:Renderer2) {
    let params = <any>(this.router.getCurrentNavigation().extras.state.report);
    if (params) {
      this.reportParams = params;
    }
  }

  public initViz(): void {

    if(this.reportParams.report_type == 2){

    const containerDiv = document.getElementById('vizContainer');   
    const vizUrl = this.reportParams.report_link;
    // https://prod-apnortheast-a.online.tableau.com/t/amnet/views/ExecutiveDashboard/ExecutiveDashboard/f455b6f8-5c35-479d-8010-1b098ebcd731/046fb839-4c33-4f51-840e-4f23fe87dbaa?:display_count=n&:showVizHome=n&:origin=viz_share_link
    // const vizUrl = 'https://prod-apnortheast-a.online.tableau.com/t/amnet/views/ExecutiveDashboard/ExecutiveDashboard';
    ///f455b6f8-5c35-479d-8010-1b098ebcd731/046fb839-4c33-4f51-840e-4f23fe87dbaa';
    //'https://public.tableau.com/views/WorldIndicators/GDPpercapita';
    const options = {
      width: containerDiv.offsetWidth,
      height: 700
    };

    const viz = new Tableau.Viz(containerDiv, vizUrl, options);
    // const viz2 = new Tableau.Viz(containerDiv2, vizUrl2, options);
  } else if(this.reportParams.report_type == 4){
    this.report_content = this.reportParams.report_content;
    var parser = new DOMParser();
	  var doc = parser.parseFromString(this.reportParams.report_content, 'text/html');
    let contentTag = doc.body.firstElementChild;
    (<any>contentTag).width = '1200';   
    setTimeout(() => {
      this.renderer.appendChild(this.reportContent.nativeElement, contentTag);      
    }, 1500)
             
  }
}

  public ngOnInit(): void {
    this.initViz();
  }
}
