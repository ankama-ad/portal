import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { AuthenticationService } from '../../services/authentication.service';

@Component({
  selector: 'app-authentication',
  templateUrl: './authentication.component.html',
  styleUrls: ['./authentication.component.scss']
})
export class AuthenticationComponent implements OnInit {

  constructor(private route: ActivatedRoute, private authenticationService: AuthenticationService, private router: Router) {
    this.route.queryParamMap.subscribe((c: any) => {
      debugger;
      if (c.params.token) {
        this.authenticationService.setToken(c.params.token)
        this.authenticationService.setcurrentUser();
        debugger;
        if (!c.params.returnTo || c.params.returnTo == 'undefined') {
          this.router.navigate(['/dashboard']);
        } else {
          this.router.navigateByUrl(c.params.returnTo);
        }
      }
    });
  }

  ngOnInit(): void {

  }

}
