import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SharedReportsComponent } from './shared-reports.component';

const routes: Routes = [{ path: '', component: SharedReportsComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SharedReportsRoutingModule { }
