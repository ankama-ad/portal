import { HttpClient, HttpContext, HttpContextToken, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse } from "@angular/common/http";
import { identifierModuleUrl } from "@angular/compiler";
import { Injectable } from "@angular/core";
import { Observable, of, share, tap } from "rxjs";


@Injectable()
export class CacheService {
  private item: any = false;
  setItem(key: string, item: Observable<any>): void {
    this.item[key] = item;
  }
  getItem(key: string): Observable<any> | undefined {
    return this.item[key];
  }

  invalidate(key: string): void { }
}

export const CACHE_REQUEST = new HttpContextToken<{
  cached: boolean;
  id: string;
}>(():any => {  cached: false;  id: null});


@Injectable()
export class CacheInterceptor implements HttpInterceptor {
  private cache: Map<string, HttpResponse<any>> = new Map()
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const { cached, id } = request.context.get(CACHE_REQUEST)

    if (cached && id) {
      let observable = this.cache.get(id);

      if (observable) {
        return of(observable);
      } else {
        return next.handle(request).pipe(
          tap(stateEvent => {
            if (stateEvent instanceof HttpResponse) {
              this.cache.set(id, stateEvent.clone())
            }
          })
        );
      }
    }
    return next.handle(request);
  }
}
