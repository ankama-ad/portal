module.exports = {
    "authenticationMode": "MasterUser",
    "authorityUri": "https://login.microsoftonline.com/common/v2.0",
    "scope": "https://analysis.windows.net/powerbi/api",
    "apiUrl": "https://api.powerbi.com/",  
    "LOIGN_URL": 'https://enterprisereportingdev.azurewebsites.net/login?returnTo=',
    "LOGIN_REDIRECT_URL": 'https://enterprisereportingdev.azurewebsites.net/#/authenticate?returnTo=',
    "HOST_URL": "https://enterprisereportingdev.azurewebsites.net",
    "AZURE_CLIENT_ID": 	"e4847564-ed0b-4ae5-8a8e-62db5ca5ce84",
    "AZURE_TENANT_ID": "de9231de-45f4-4325-ae07-8ae72052517e",
    "AZURE_CLIENT_SECRET": "ZJTmUMqKpCifE126.wh3~_9~pF5s57Rr5-"
}