// ----------------------------------------------------------------------------
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
// ----------------------------------------------------------------------------

let path = require('path');
const utils = require("./backend/utils.js");

//const { logError, isOperationalError } = require('./backend/errorHandler')
const { logger, logError, logInfo } = require('./backend/logger')
const httpLogger = require('./backend/httplogger')




const session = require('express-session');
const msalWrapper = require('msal-express-wrapper');
const config = require('./appSettings.js');
const cache = require('./utils/cachePlugin');
const mainController = require('./controllers/mainController');
// const res = require("./backend/services/sequalize.service").verifyDBConnection();
const powerbiRouter = require("./backend/routes/powerbiEmbedRoutes");
const reportRoutes = require("./backend/routes/reportRoutes");
const deprtmentRoutes = require("./backend/routes/departmentRoutes");
const userRolesRoutes = require("./backend/routes/userRolesRoutes");
const usersRoutes = require("./backend/routes/usersRoutes");
const clientContextRoutes = require("./backend/routes/clientcontext");
const sqlRoutes = require("./backend/routes/sqlRoutes");
const loggerRoutes = require("./backend/routes/loggerRoutes");


const express = require("express");
//const bodyParser = require("body-parser");
const useragent = require('useragent');
// const Saml2js = require('saml2js');
const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const randtoken = require('rand-token');
const refreshTokens = {};
const EXPIRES_IN = 30;

/**
 * Configure JWT
 */
var jwt = require('jsonwebtoken'); // used to create, sign, and verify tokens
// var bcrypt = require('bcryptjs');

var { decryptJSON, encryptJSON, encryptResponse } = require('./backend/encrypt-decrypt');
// var config = require('./backend/config'); // get config file


let cors = require('cors');
app.use(httpLogger)
app.use(cors())
// app.use(bodyParser.urlencoded());
// app.use(bodyParser.json());
// let html_to_pdf = require('html-pdf-node');
// Prepare server for Bootstrap, jQuery and PowerBI files
app.use('/js', express.static('./node_modules/bootstrap/dist/js/')); // Redirect bootstrap JS
app.use('/js', express.static('./node_modules/jquery/dist/')); // Redirect JS jQuery
app.use('/js', express.static('./node_modules/powerbi-client/dist/')) // Redirect JS PowerBI
app.use('/css', express.static('./node_modules/bootstrap/dist/css/')); // Redirect CSS bootstrap
app.use('/public', express.static('./backend/public/')); // Use custom JS and CSS files
app.use(express.static(path.join(__dirname, 'backend/views')));


/**
 * Using express-session middleware. Be sure to familiarize yourself with available options
 * and set them as desired. Visit: https://www.npmjs.com/package/express-session
 */
const sessionConfig = {
  secret: 'ENTER_YOUR_SECRET_HERE',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: false, // set this to true on production
  }
}

if (app.get('env') === 'production') {

  /**
   * In App Service, SSL termination happens at the network load balancers, so all HTTPS requests reach your app as unencrypted HTTP requests.
   * The line below is needed for getting the correct absolute URL for redirectUri configuration. For more information, visit: 
   * https://docs.microsoft.com/azure/app-service/configure-language-nodejs?pivots=platform-linux#detect-https-session
   */

  app.set('trust proxy', 1) // trust first proxy
  sessionConfig.cookie.secure = true // serve secure cookies
}

app.use(session(sessionConfig));

// instantiate the wrapper
const authProvider = new msalWrapper.AuthProvider(config, cache);

// initialize the wrapper
app.use(authProvider.initialize());

const swaggerUi = require('swagger-ui-express');
// var swaggerDocument = require('./swagger.json');
// swaggerDocument.host = process.env.HOST_URL;

const swaggerJSDoc = require('swagger-jsdoc');

const swaggerDefinition = {
  openapi: '3.0.0',
  info: {
    title: 'API for Reporting Portal',
    version: '1.0.0',
    description:
      'This is a REST API application. It retrieves data from Reporting Portal.',
    license: {
      name: 'Licensed Under CDW',
      url: 'https://www.cdw.com',
    },
    contact: {
      name: 'Reporting Portal',
      url: 'https://entrepportalapp-dv.azurewebsites.net',
    },
  },
  servers: [
    {
      url: 'http://localhost:8080/api',
      description: 'Local server',
    },
    {
      url: 'https://entrepportalapp-dv.azurewebsites.net/api',
      description: 'Development server',
    },
    {
      url: 'https://entrepportalapp-qa.azurewebsites.net/api',
      description: 'QA server',
    },
    {
      url: 'https://entrepportalapp-dv-test.azurewebsites.net/api',
      description: 'Dev test server',
    },
  ],
};

const options = {
  swaggerDefinition,
  // Paths to files containing OpenAPI definitions
  apis: ['./backend/routes/*.js'],
};

const swaggerSpec = swaggerJSDoc(options);


const port = process.env.PORT || 8080;

// app.use(bodyParser.json());

// app.use(bodyParser.urlencoded({
//     extended: true
// }));
app.all('*', (req, res, next) => {
  try {
    logInfo({ level: 'INFO', message: 'decrypt request: TYPE OF Request Data: ' + typeof(req.body.data), 
    hostname: req.hostname, port: req.port, req: (req.protocol + "://" + req.get('host') + req.originalUrl) });
    console.log('request data type', typeof(req.body.data));    
    if (req.body.data && typeof(req.body.data) === 'string') {
      req['body'] = decryptJSON(req.body.data);
    }
  }
  catch (err) {
    logError({ level: 'error', message: 'decrypt request',  hostname: req.hostname, port: req.port, username: '', req: (req.protocol + "://" + req.get('host') + req.originalUrl) });     
    //log here
  }
  next();
})


function encryptResponseInterceptor(req, res, next) {
  try {
  console.log(req.url);
  const originalSend = res.send;
  //if (req.url.indexOf('api') > -1 && (!req.headers['swg-response']) && (process.env.DISABLE_ENC !== 'true')) {
  if (req.url && req.url.indexOf('api') > -1) {
      res.send = function () {
      arguments[0] = encryptResponse(arguments[0]);
      originalSend.apply(res, arguments);
    };
  }
  next();
}catch(ex){ 
  logError({ level: 'error', message: 'encrypt response',  hostname: req.hostname, port: req.port, username: '', req: (req.protocol + "://" + req.get('host') + req.originalUrl) });     
  console.log(ex);
}
}

function encryptResponse(originalData) {
  // place your encryption logic here, I'm just adding a string in this example
  return originalData + " modified";
}
// app.use(encryptResponseInterceptor);
// app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
app.use('/docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));
app.use('/api/powerbi', powerbiRouter);
app.use('/api/reports', reportRoutes);
app.use('/api/departments', deprtmentRoutes);
app.use('/api/userroles', userRolesRoutes);
app.use('/api/users', usersRoutes);
app.use('/api/clientcontext', clientContextRoutes);
app.use('/api/sql', sqlRoutes);
app.use('/api/logger', loggerRoutes);


app.get('/', function (req, res) {
  res.sendFile(path.join(__dirname + '/views/index.html'));
  //res.sendFile(path.join(__dirname + '/../templates/index.html'));

});

app.get('/template', function (req, res) {
  res.sendFile(path.join(__dirname + '/../templates/index.html'));
});


// authentication routes
app.get('/signin',
  //  (req, res, next) => {
  //       const { returnTo, origin } = req.query
  //       const state = returnTo ? Buffer.from(JSON.stringify({ returnTo })).toString('base64') : undefined     
  //       req.session.state = state;
  //       req.session.host = origin;
  //       console.log('session', req.session);
  //       next()     
  //  },
  authProvider.signIn({ successRedirect: '/signincallback' }));
app.get('/signout', authProvider.signOut({ successRedirect: '/' }));

// secure routes
app.get('/id', authProvider.isAuthenticated(), mainController.getIdPage);

app.get('/profile',
  authProvider.getToken({
    resource: config.remoteResources.graphAPI
  }),
  mainController.getProfilePage
);


app.get('/signincallback',
  (req, res) => {

    console.log('************************************ CreateUserSession called ********************************');

    try {
      // console.log(req.session)


      // const { state, host } = req.session;
      // const {returnTo }  = state ? JSON.parse(Buffer.from(state, 'base64').toString()): '';
      // if (typeof returnTo === 'string' && returnTo ==='undefined') {
      returnTo = '';
      // }

      // create a token
      //  var token = jwt.sign({ id: 'ajay' }, config.Secret, {
      //   expiresIn: config.EXPIRES_IN // expires in 24 hours
      // });
      // const refreshToken = randtoken.uid(256);
      //refreshTokens[refreshToken] = User.email;
      // console.log('refreshtoken', refreshTokens);
      // return the information including token as JSON

      // const user = await userService.getUserByEmail(req.userDetails.email);
      // if(!user){
      //     return res.redirect(302, `${process.env.DOMAIN_RL}/validate-sso-token?error=User Not reqistered with BrightLab`);        
      // }
      // const ssoResponse = loginDato.createWSSORespSameAsDeep(req.userDetails, user);
      //const session =  await sessionService.createSession(user, null, false, req.deviceInfo, true, ssoResponse);
      //const token = cassndraUtil.generateTimeuuid();
      // await redisUtil.save(token, session.data, 60);
      // res.cookie('Authorization', session);
      //return res.redirect(302, `${process.env.DOMAIN_URL}/validate-sso-token?token=${token}`);
      // let userInfo = {};
      // let claimPrefix = 'httpSchemasMicrosoftComClaims;'
      // Object.keys(req.samlUserObject).forEach(key => {       
      //     userInfo[key.substr(claimPrefix.length)] = req.samlUserObject[key];       
      // });

      // console.log(host);
      // res.cookie("loggedInUser", JSON.stringify(req.session.account));
      // return res.redirect(302, `${host}/#/authenticate?returnTo=${returnTo}&token=${req.samlResponse}`);
       // res.send(res.session);
      return res.redirect(302, `${process.env.CLIENT_DOMAIN}authenticate?token=${req.sessionID}`);
      // return res.redirect(302, `http://localhost:8080/profile`);
      // userLogin.createUserSession(res, req);
    } catch (ex) {      
      console.log(ex.message, ex.stack);
      logError({ level: 'error', message: ex.message,  
      hostname: req.hostname, port: req.port, username: '', 
      req: (req.protocol + "://" + req.get('host') + req.originalUrl) });     

    }
  }
);

app.get('/tenant',
  authProvider.getToken({
    resource: config.remoteResources.armAPI
  }),
  mainController.getTenantPage
);


// app.get('/getEmbedToken', async function (req, res) {

//     // Validate whether all the required configurations are provided in config.json
//     // configCheckResult = utils.validateConfig();
//     // if (configCheckResult) {
//     //     return {
//     //         "status": 400,
//     //         "error": configCheckResult
//     //     };
//     // }
//     // Get the details like Embed URL, Access token and Expiry
//     let result = await embedToken.getEmbedInfo();

//     // result.status specified the statusCode that will be sent along with the result object
//     res.status(result.status).send(result);
// });


// get the unhandled rejection and throw it to another fallback handler we already have.
process.on('unhandledRejection', error => {
  console.log('unhandledRejection', error.message);
  console.log(error.stack);
  logError({ level: 'error', message: 'unhandledRejection' + error.message,  hostname: '', port: '', 
  username: 'ankam.bollimuntha@cdw.com', 
  req: '' })      
  throw error
})

process.on('uncaughtException', error => {
  
  console.log('unhandledRejection', error.message);
  console.log(error.stack);
  logError({ level: 'error', message: 'uncaughtException' + error.message,  hostname: '', port: '', 
  username: 'ankam.bollimuntha@cdw.com', 
  req: '' })  

  // if (!isOperationalError(error)) {
  //   process.exit(1)
  // }
})

const userAgentHandler = (req, res, next) => {
  const agent = useragent.parse(req.headers['user-agent']);
  const deviceInfo = Object.assign({}, {
    device: agent.device,
    os: agent.os,
  });
  req.device = deviceInfo;
  next();
};




// catch 404 
app.use(function (req, res, next) {
  console.log('env', req.app.get('env'));
  res.status(404);
  res.format({
    html: function () {
      res.render('404', { url: req.url })
    },
    json: function () {
      res.json({ error: 'Not found' })
    },
    default: function () {
      res.type('txt').send('Not found')
    }
  })
});

// error handler
app.use(function (err, req, res, next) {
  // set locals, only providing error in development
  // res.locals.message = err.message;
  // res.locals.error = req.app.get('env') === 'development' ? err : {};
  logError(err)
  // render the error page
  res.status(err.status || 500);
  res.send(err);
});

module.exports = app;