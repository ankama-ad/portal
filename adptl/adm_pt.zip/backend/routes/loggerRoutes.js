
const loggerService = require('../services/loggerService');
const express = require("express");
const router = express.Router();


/**
 * @swagger
 * /logger/logerrors:
 *  post:
 *   description: query Submitted by the user
 *   tags: [DB Test]
 *   requestBody:
 *     content:
 *       'application/json':
 *         schema:
 *          properties:
 *             userId: 
 *               description: Updated name of the pet
 *               type: string
 *             userName: 
 *               description: eexcute
 *               type: string
 *             logLevel:
 *               description: Updated status of the pet
 *               type: string
 *             logDescription:
 *               description: Updated status of the pet
 *               type: string
 *            
 *          required:
 *            - userId
 *            - userName 
 *            - logLevel
 *            - logDesciption
 *            - isActive
 *           
 *   responses:
 *
 *     '200':
 *       description: Pet updated.
 *       content: 
 *         'application/json': {}
 */

router.post('/logerrors', [
    loggerService.insertLog
]);

module.exports = router;
