//const UsersController = require('./controllers/users.controller');
// const PermissionMiddleware = require('../common/middlewares/auth.permission.middleware');
//const ValidationMiddleware = require('../common/middlewares/auth.validation.middleware');
// const config = require('../common/config/env.config');
const reportService = require('../services/reportService');
const express = require("express");
const router = express.Router();


/**
 * @swagger
 * components:
 *   schemas:
 *     NewUser:
 *       type: object
 *       properties:
 *         name:
 *           type: string
 *           description: The user's name.
 *           example: Leanne Graham
 *     User:
 *       allOf:
 *         - type: object
 *           properties:
 *             id:
 *               type: integer
 *               description: The user ID.
 *               example: 0
 *             accessLevelId:
 *               type: integer
 *               description: The user ID.
 *               example: 0
 *             accessLevelName:
 *               type: integer
 *               description: The user ID.
 *               example: 0
 *         - $ref: '#/components/schemas/NewUser'
 *     AdminRole:
 *           properties:
 *             adminRoleId:
 *               type: integer
 *               description: The user ID.
 *               example: 0
 *             adminRoleName:
 *               type: string
 *               description: admin Role Name.
 *               example: Portal Admin (Default)
 *             adminRoleDescription:
 *               type: string
 *               description: Portal Admin (Default) description.
 *               example: Portal Admin (Default) description.
 */

/**
 * @swagger
 * /reports/getReports:
 *   get:
 *     tags:
 *      - Reports
 *     summary: Retrieve a list of JSONPlaceholder users.
 *     description: Retrieve a list of users from JSONPlaceholder. Can be used to populate a list of fake users when prototyping or testing an API.
 *     responses:
 *       200:
 *         description: A list of users.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/User'
*/

router.get('/getReports', [
    //ValidationMiddleware.validJWTNeeded,
    // PermissionMiddleware.minimumPermissionLevelRequired(PAID),
    reportService.getReports

]);

router.get('/getUserReports/:email', [
    //ValidationMiddleware.validJWTNeeded,
    // PermissionMiddleware.minimumPermissionLevelRequired(PAID),
   //  reportService.getUserReports

]);



module.exports = router;
