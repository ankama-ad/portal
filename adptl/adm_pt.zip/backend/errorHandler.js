const { logger } = require('./logger');
const BaseError = require('./baseError');
const loggerService = require('./services/loggerService');

function logError(err) {
    logger.error({ message: messageFormatter(err) });
        loggerService.insertBackendLog('17474', err.username, 'error', messageFormatter(err));
}
function logWarning(err) {
    logger.warning({ message: messageFormatter(err) });
        loggerService.insertBackendLog('111', 'abc', 'warning', messageFormatter(err));
}
function logInfo(err) {
    logger.info({ message: messageFormatter(err) });
        loggerService.insertBackendLog('111', 'abc', 'info', messageFormatter(err));
}
function logErrorMiddleware(err, req, res, next) {
    logError(err);
    next(err);
}

function returnError(err, req, res, next) {
    res.status(err.statusCode || 500).send(err.message);
}

function isOperationalError(error) {
    if (error instanceof BaseError) {
        return error.isOperational;
    }
    return false;
}

function messageFormatter(msg) {
    try {
        return JSON.stringify(msg);
    }
    catch {
        return msg;
    }
}
module.exports = {
    logError,
    logWarning,
    logInfo,
    logErrorMiddleware,
    returnError,
    isOperationalError
}