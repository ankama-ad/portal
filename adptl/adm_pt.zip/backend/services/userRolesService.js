
const { Op, QueryTypes, JSON } = require("sequelize");
const adminRolePermissions = require("../models/adminRolePermissions");
const client = require('../keyVault');
const Sequelize = require('sequelize');
// const { DefaultAzureCredential } = require("@azure/identity");
var dbContext = require("./dbcontext");
const { componentWrapper, apiResponse } = require("../common");
const { performance } = require('perf_hooks');
const { logInfo, logError, logger } = require('../logger');
const {encryptJSON, encryptResponse} = require('../encrypt-decrypt');

// exports.getUserRoles = async (req, res) => {
//     contex.getContext().accessLevel.findAll({
//         where: { isActive: { [Op.eq]: true } }
//     }).then((result) => {
//         res.send(encryptResponse(result));
//     });
// };

// exports.getAdminRoleUsers = (req, res) => {

//     if (req.params.adminRoleTypId == 1) {
//         contex.sequelize.query(`
//     select au.user_id No, us.first_name +' ' + us.last_name AdminName from admin_users au 
//     join users us on au.user_id = us.user_id
//     `, { type: QueryTypes.SELECT }).then((result) => {
//             res.send(encryptResponse(result));
//         });
//     } else if (req.params.adminRoleTypId == 2) {
//         this.getDepartmentRoleUsers(req, res);
//     } else if (req.params.adminRoleTypId == 3) {
//         this.getGroupRoleUsers(req, res);
//     }
//     else if (req.params.adminRoleTypId == 4) {
//         this.getDepartmentRoleUsers(req, res);
//     }
// };

// exports.getDepartmentRoleUsers = (req, res) => {
//     contex.sequelize.query(`
//     SELECT
//       da.department_id departmentId,
// 	 dp.department_name departmentName,
//       da.user_id userId,
// 	  us.first_name + ' '+ us.last_name adminName
//   FROM [dbo].[department_admin] da
//    join Departments dp on da.department_id = dp.department_id
//    join Users us on da.user_id = us.user_id
//    where dp.is_active = 1 and da.admin_role_id = ${req.params.adminRoleId}
//     `, { type: QueryTypes.SELECT }).then((result) => {
//         res.send(encryptResponse(result));
//     });
// };

// exports.getGroupRoleUsers = (req, res) => {
//     contex.sequelize.query(`
//     SELECT
//       ga.user_group_id userGroupId,
// 	  ug.user_group_name userGroupName,
// 	  ga.user_id userId, 
// 	  dp.department_name departmentName,      
// 	  us.first_name + ' '+ us.last_name adminName,
// 	  ga.admin_role_id adminRoleId,
// 	  adr.admin_role_name adminRole
//   FROM group_admin ga
//    join UserGroups ug  on ga.user_group_id = ug.user_group_id
//    join Users us on ga.user_id = us.user_id
//    join Departments dp on ug.dept_id = dp.department_id
//    join admin_roles adr on adr.admin_role_id = ga.admin_role_id
//    where ug.is_active = 1 and ga.admin_role_id = ${req.params.adminRoleId}
//     `, { type: QueryTypes.SELECT }).then((result) => {
//         res.send(encryptResponse(result));
//     });
// };

exports.getAdminRoles = async (req, res) => {

    var options = {};
    options.query = `
                    SELECT ar.admin_role_id adminRoleId, ar. admin_role_name adminRoleName, ar.admin_role_description adminRoleDescription, ar.admin_role_type_id adminRoleTypeId, art.admin_role_type_name roleType, count(au.user_id) assignedUsers
                    FROM admin_roles ar
                    left join admin_role_types art on ar.admin_role_type_id = art.admin_role_type_id
                    left join admin_users au on ar.admin_role_id = au.admin_role_id
                    where ar.is_active =1
                    group by ar.admin_role_id, ar. admin_role_name, ar.admin_role_description,  ar.admin_role_type_id, art.admin_role_type_name
    `;
    req.options = options;
    let result = {};
    try {
        result = await componentWrapper(req, res);
    } catch (ex) {
        console.log('catched ex', ex);                
    } finally {

        res.status((result.metadata &&  result.metadata.responseStatus) ? result.metadata.responseStatus: 500);
        //res.send(encryptResponse(result));
        res.send(encryptResponse(result));
    }
};

// exports.getAdminRolesPermissions = async (req, res) => {

//     contex.sequelize.query(`
//     WITH Category_Cte (categoryId, categoryName, parentCategory, parentCategoryName)  AS  
//     (  
//         SELECT ctg.admin_permission_category_id categoryId, ctg.admin_permission_category_name categoryName, 		
//         ctg.parent_category_id prentCategory,
//         CASE WHEN pctg.admin_permission_category_name IS NULL THEN ctg.admin_permission_category_name  ELSE pctg.admin_permission_category_name END prentCategoryName	
//         FROM admin_permission_category  ctg 
//         left join admin_permission_category  pctg on ctg.parent_category_id = pctg.admin_permission_category_id
//     )
//     select cat.*, 
//     ad_pms.admin_permission_id adminPermissionId, ad_pms.admin_permission_name adminPermissionName, 
//     ad_role_pms.is_view isView, ad_role_pms.is_add isAdd, ad_role_pms.is_edit isEdit, ad_role_pms.is_delete idDelete from Category_Cte cat
//     join admin_permissions  ad_pms on cat.categoryId = ad_pms.admin_permission_category_id  
//     join admin_role_permissions ad_role_pms on ad_pms.admin_permission_id = ad_role_pms.admin_permission_id
//     join admin_permission_category_configuration allowd_pms on ad_pms.admin_permission_category_id = allowd_pms.admin_permission_category_id
//     where ad_role_pms.admin_role_id = ${req.params.adminRoleId} and allowd_pms.admin_role_type_id = ${req.params.adminRoleTypId}
//     order by parentCategory desc
//     `, { type: QueryTypes.SELECT }).then((result) => {

//         // const nest = (items, id = null, link = 'parentCategory') => {
//         //    let parents =  items.filter(item => item[link] === id);
//         //    let fitems =  parents.map(item => ({ ...item, children: nest(items, item.categoryId) }));
//         //    return fitems; 
//         // }

//         const nest = (items, id = null, link = 'parentCategory') => {
//             let parents = items.filter(item => item[link] === id);
//             let fitems = parents.map(item => ({ ...item, children: item.children.concat(nest(items, item.categoryId)) }));
//             return fitems;
//         }
//         // console.log('nest', nest(result));

//         rst = [];

//         result.forEach(function (a) {
//             if (!this[a.categoryName] && !this[a.parentCategoryName]) {
//                 this[a.categoryName] = {
//                     categoryId: a.categoryId, categoryName: a.categoryName, parentCategory: a.parentCategory, adminPermissionName: a.categoryName,
//                     parentCategoryName: a.parentCategoryName, children: []
//                 };
//                 rst.push(this[a.categoryName]);
//             }
//             this[a.categoryName].children.push({
//                 categoryId: a.categoryId, adminPermissionName: a.adminPermissionName,
//                 categoryName: a.categoryName, parentCategory: a.parentCategory, adminPermissionId: a.adminPermissionId,
//                 isView: a.isView, isAdd: a.isAdd, isDelete: a.isDelete, isEdit: a.isEdit,
//                 parentCategoryName: a.parentCategoryName, children: []
//             });

//         }, Object.create(null));

//         console.log(rst);
//         res.send(nest(rst));
//     });
// };

exports.getAdminRoleTypePermissionConfiguration = async (req, res) => {

    var options = {};
    options.query = `
     WITH Category_Cte (categoryId, categoryName, parentCategory, parentCategoryName)  AS  
    (  
        SELECT ctg.admin_permission_category_id categoryId, ctg.admin_permission_category_name categoryName, 		
        ctg.parent_category_id prentCategory,
        CASE WHEN pctg.admin_permission_category_name IS NULL THEN ctg.admin_permission_category_name  ELSE pctg.admin_permission_category_name END prentCategoryName	
        FROM admin_permission_category  ctg 
        left join admin_permission_category  pctg on ctg.parent_category_id = pctg.admin_permission_category_id
    )
    select cat.*, 
    ad_pms.admin_permission_id adminPermissionId, ad_pms.admin_permission_name adminPermissionName, ad_pms.admin_permission_description adminPermissionDescription,
    ad_role_pms.admin_role_type_permission_configuration_id adminRoleTypePermissionConfigurationId, 
    permissionCategoriesConfig.admin_permission_category_configuration_id adminPermissionCategoryConfigurationId, 
    permissionCategoriesConfig.is_active categoryActiveStatus,
	ad_role_pms.is_active isActive,
    case when ad_role_pms.admin_role_type_permission_configuration_id is null then ad_pms.is_view  else ad_role_pms.is_view end isView,
	case when ad_role_pms.admin_role_type_permission_configuration_id is null then ad_pms.is_add  else ad_role_pms.is_add end isAdd, 
	case when ad_role_pms.admin_role_type_permission_configuration_id is null then ad_pms.is_edit  else ad_role_pms.is_edit end isEdit,
	case when ad_role_pms.admin_role_type_permission_configuration_id is null then ad_pms.is_delete  else ad_role_pms.is_delete end isDelete   
	from Category_Cte cat
    left join admin_permissions  ad_pms on cat.categoryId = ad_pms.admin_permission_category_id  
    left join admin_role_type_permission_configuration ad_role_pms on ad_pms.admin_permission_id = ad_role_pms.admin_permission_id 
															and ad_role_pms.admin_role_type_id =  ${req.params.adminRoleTypeId} 
	left join admin_permission_category_configuration 
				permissionCategoriesConfig on cat.categoryId = permissionCategoriesConfig.admin_permission_category_id 
															and permissionCategoriesConfig.admin_role_type_id =  ${req.params.adminRoleTypeId} 
    
    order by parentCategory desc       
    `;
    req.options = options;
    let result = {};
    try {
        result = await componentWrapper(req, res);

        const nest = (items, id = null, link = 'parentCategory') => {
            let parents = items.filter(item => item[link] === id);
            let fitems = parents.map(item => ({ ...item, children: item.children.concat(nest(items, item.categoryId)) }));
            return fitems;
        }
        // console.log('nest', nest(result));
        rst = [];
        result.response.forEach(function (a) {
            if (!this[a.categoryName] && !this[a.parentCategoryName]) {
                this[a.categoryName] = {
                    categoryId: a.categoryId, categoryName: a.categoryName, parentCategory: a.parentCategory, adminPermissionName: a.categoryName,
                    parentCategoryName: a.parentCategoryName, isActive: a.categoryActiveStatus,
                    adminPermissionCategoryConfigurationId: a.adminPermissionCategoryConfigurationId,
                    children: []
                };
                rst.push(this[a.categoryName]);
            }
            this[a.categoryName].children.push({
                categoryId: a.categoryId, adminPermissionName: a.adminPermissionName, adminPermissionDescription: a.adminPermissionDescription,
                categoryName: a.categoryName, parentCategory: a.parentCategory, adminPermissionId: a.adminPermissionId,
                isView: a.isView, isAdd: a.isAdd, isDelete: a.isDelete, isEdit: a.isEdit, isActive: a.isActive,
                adminRoleTypePermissionConfigurationId: a.adminRoleTypePermissionConfigurationId,
                parentCategoryName: a.parentCategoryName, children: []
            });

        }, Object.create(null));
        result.response = nest(rst)
    } catch (ex) {
        console.log(ex);
        // res.send(ex);
    } finally {
        res.status(result.metadata.responseStatus);
        //res.send(encryptResponse(result));
        res.send(encryptResponse(result));
    }
};

exports.getAdminRoleTypePermissions = async (req, res) => {

    var options = {};
    options.query = `
    WITH Category_Cte (categoryId, categoryName, parentCategory, parentCategoryName)  AS  
    (  
        SELECT ctg.admin_permission_category_id categoryId, ctg.admin_permission_category_name categoryName, 		
        ctg.parent_category_id prentCategory,
        CASE WHEN pctg.admin_permission_category_name IS NULL THEN ctg.admin_permission_category_name  ELSE pctg.admin_permission_category_name END prentCategoryName	
        FROM admin_permission_category  ctg 
        left join admin_permission_category  pctg on ctg.parent_category_id = pctg.admin_permission_category_id
    )
    select cat.*, 
    ad_pms.admin_permission_id adminPermissionId, ad_pms.admin_permission_name adminPermissionName, ad_pms.admin_permission_description adminPermissionDescription,
    ad_role_pms.admin_role_type_permission_configuration_id adminRoleTypePermissionConfigurationId, 
    permissionCategoriesConfig.admin_permission_category_configuration_id adminPermissionCategoryConfigurationId, 
    permissionCategoriesConfig.is_active isActive,
     ad_role_pms.is_view  isView,
	 ad_role_pms.is_add  isAdd, 
	 ad_role_pms.is_edit  isEdit,
	 ad_role_pms.is_delete  isDelete   
	from Category_Cte cat
     join admin_permissions  ad_pms on cat.categoryId = ad_pms.admin_permission_category_id  
     join admin_role_type_permission_configuration ad_role_pms on ad_pms.admin_permission_id = ad_role_pms.admin_permission_id 
															and ad_role_pms.is_active = 1
															and ad_role_pms.admin_role_type_id =  ${req.params.adminRoleTypeId}
	 join admin_permission_category_configuration 
				permissionCategoriesConfig on cat.categoryId = permissionCategoriesConfig.admin_permission_category_id 
															and permissionCategoriesConfig.is_active = 1
															and permissionCategoriesConfig.admin_role_type_id =  ${req.params.adminRoleTypeId} 
    order by parentCategory  desc														    
    `;
    req.options = options;
    let result = {};
    try {
        result = await componentWrapper(req, res);

        const nest = (items, id = null, link = 'parentCategory') => {
            let parents = items.filter(item => item[link] === id);
            let fitems = parents.map(item => ({ ...item, children: item.children.concat(nest(items, item.categoryId)) }));
            return fitems;
        }
        // console.log('nest', nest(result));
        rst = [];
        result.response.forEach(function (a) {
            if (!this[a.categoryName] && !this[a.parentCategoryName]) {
                this[a.categoryName] = {
                    categoryId: a.categoryId, categoryName: a.categoryName, parentCategory: a.parentCategory, adminPermissionName: a.categoryName,
                    parentCategoryName: a.parentCategoryName, children: []
                };
                rst.push(this[a.categoryName]);
            }
            this[a.categoryName].children.push({
                categoryId: a.categoryId, adminPermissionName: a.adminPermissionName,
                categoryName: a.categoryName, parentCategory: a.parentCategory, adminPermissionId: a.adminPermissionId,
                isView: a.isView, isAdd: a.isAdd, isDelete: a.isDelete, isEdit: a.isEdit,
                parentCategoryName: a.parentCategoryName, children: []
            });

        }, Object.create(null));
        let items = nest(rst);
        result.response =  items.sort((a, b) =>  a.categoryId - b.categoryId); 
    } catch (ex) {
       //  res.send(ex);
    } finally {
        res.status(result.metadata.responseStatus);
       //res.send(encryptResponse(result));
       res.send(encryptResponse(result));
    }
};

exports.getAdminRoleTypes = async (req, res) => {
    var options = {};
    options.query = "  SELECT admin_role_type_id as adminRoleTypeId ,admin_role_type_name as adminRoleTypeName , entity  FROM [dbo].[admin_role_types]";
    req.options = options;
    let result = {};
    try {
        result = await componentWrapper(req, res);
    } catch (ex) {
        logError({ level: 'error', message: 'get AdminRoleTypes api',  hostname: req.hostname, port: req.port, username: 'ankam.bollimuntha@cdw.com', req: (req.protocol + "://" + req.get('host') + req.originalUrl) })   
        // res.send(ex);
    } finally {
        res.status(result.metadata.responseStatus);
       //res.send(encryptResponse(result));
       res.send(encryptResponse(result));
    }
};

exports.addAdminRole = async (req, res) => {
    let result = apiResponse;
    // process.env.user= "ad_user"
    // var options = {};
    // adminRoleInsertQuery = `INSERT INTO [dbo].[admin_roles] ([admin_role_name] ,[admin_role_description],
    // [is_default_role],[is_active],[created_by],[created_date],[modified_by],[modified_date])
    // VALUES (:adminRoleName,:adminRoleDescription,:isDefaultRole :isActive, :createdBy, 
    // :createdDate)`;
    // let adminRoleParams = {
    //     adminRoleTypeId: req.body.adminRoleTypeId,
    //     adminRoleName: req.body.adminRoleName,
    //     isDefaultRole:  !!req.body.isDefaultRole,
    //     isActive: true,
    //     adminRoleDescription: req.body.adminRoleDescription,
    //     createdBy: process.env.user,
    //     modifiedBy: process.env.user
    // }    
    // req.options = options;       
    try {
        // req.options.query = adminRoleInsertQuery;        
        // req.options.queryParams = adminRoleParams;
        // result = await componentWrapper(req, res);  
        // req.options.query = adminPermissionsInsertQuery; 
        // req.options.queryParams = adminPermissionParams;  
        // result = await componentWrapper(req, res);

        const ctx = await dbContext.getContext();
        const dbctx = await dbContext.getModels();
        // // result.metadata.rows = response.result.rowsAffected;        
        let addRoleresult = await dbctx.adminRoles.create({
            adminRoleTypeId: req.body.adminRoleTypeId,
            adminRoleName: req.body.adminRoleName,
            isActive: true,
            adminRoleDescription: req.body.adminRoleDescription,
        });
        let rolePermissions = req.body.permissions;
        rolePermissions.forEach(c => {
            c.isActive = true;
            c.adminRoleId = addRoleresult.adminRoleId, c.adminRoleTypeId = req.body.adminRoleTypeId;
        });
        let permissionResult = await dbctx.adminRolePermissions.bulkCreate(rolePermissions);
        console.log('permissionResult', permissionResult);
        result.metadata.rows = permissionResult.length;
        result.metadata.responseStatus = 200;
        result.response = {
            adminRoleId: addRoleresult.adminRoleId, permissionsIds:
                permissionResult.map(c => c.adminRolePermissionId)
        };
    } catch (ex) {
        // res.send(ex);
    } finally {
        res.status(result.metadata.responseStatus);
        //res.send(encryptResponse(result));
        res.send(encryptResponse(result));
    }

};

exports.updateAdminRoleTypePermissionConfiguration = async (req, res) => {
    let result = apiResponse;

    try {

        const ctx = await dbContext.getContext();
        const dbctx = await dbContext.getModels();
        // // result.metadata.rows = response.result.rowsAffected;        
        let updatesresultpermisions = [];
        let updatesresultcategories = [];
        let rolePermissions = req.body.permissions;
        let adminRoleTypePermissionIds = rolePermissions.map(c => c.adminRoleTypePermissionConfigurationId);
        // let pms = await dbctx.adminRoleTypePermissionConfiguration.findAll(
        //     { where: { adminRoleTypePermissionConfigurationId: adminRoleTypePermissionIds } });
        for (let pc of rolePermissions) {
            let pct = await dbctx.adminRoleTypePermissionConfiguration.findOne(
                { where: { adminRoleTypePermissionConfigurationId: pc.adminRoleTypePermissionConfigurationId } });
            // let pc = rolePermissions.find(d => d.adminRoleTypePermissionConfigurationId == pct.adminRoleTypePermissionConfigurationId)
            if (pct) {
                let updatesresultpermision = await pct.update(
                    {
                        isActive: !!pc.isActive,
                        isView: pc.isView, isEdit: pc.isEdit,
                        isAdd: pc.isAdd, isDelete: pc.isDelete
                    });
                updatesresultpermisions.push(updatesresultpermision);
            } else {
                let md = {
                    adminRoleTypeId: req.body.adminRoleTypeId,
                    adminPermissionId: pc.adminPermissionId,
                    isActive: !!pc.isActive,                    
                        isView: pc.isView, isEdit: pc.isEdit,
                        isAdd: pc.isAdd, isDelete: pc.isDelete
                    // createdBy : pc.createdBy,
                    // createdDate : pc.createdDate,
                    // modifiedBy : pc.modifiedBy,
                    // modifiedDate : pc.modifiedDate,
                }
                let rc = await dbctx.adminRoleTypePermissionConfiguration.create(md);
                updatesresultpermisions.push(rc);
            }
        }

        // let permissionResult = await dbctx.adminRoleTypePermissionConfiguration.bulkCreate(rolePermissions, 
        //     {updateOnDuplicate: ["adminRoleTypePermissionConfigurationId"]});
        // console.log('permissionResult', permissionResult);       
        let permissionCategory = req.body.categories;
        let adminRoleTypeIds = permissionCategory.map(c => c.adminPermissionCategoryConfigurationId);
        // let categories = await dbctx.adminPermissionCategoryConfiguration.findAll(
        //     { where: { adminPermissionCategoryConfigurationId: adminRoleTypeIds } });
        for (let pca of permissionCategory) {
            // let pca = permissionCategory.find(d => d.adminPermissionCategoryConfigurationId == ct.adminPermissionCategoryConfigurationId)
            let ct = await dbctx.adminPermissionCategoryConfiguration.findOne(
                { where: { adminPermissionCategoryConfigurationId: pca.adminPermissionCategoryConfigurationId } });
            if (ct) {
                let updatesresultcategory = await ct.update({ isActive: !!pca.isActive });
                updatesresultcategories.push(updatesresultcategory);
            } else {
                // pca.isActive = true;
                let config = {
                    isActive: !!pca.isActive,
                    adminPermissionCategoryId: pca.adminPermissionCategoryId,
                    adminRoleTypeId: req.body.adminRoleTypeId
                }
                let cnf = await dbctx.adminPermissionCategoryConfiguration.create(config)
                updatesresultcategories.push(cnf);
            }

        }

        console.log('****************************send response *******************************');

        result.metadata.rows = adminRoleTypePermissionIds.length + adminRoleTypeIds.length;
        result.metadata.responseStatus = 200;
        result.response = {
            categoryIds: adminRoleTypeIds,
            permissionIds: adminRoleTypePermissionIds
        };
    } catch (ex) {
        // res.send(ex);
        result.metadata.responseStatus = 500;
    } finally {
        res.status(result.metadata.responseStatus);
       //res.send(encryptResponse(result));
       res.send(encryptResponse(result));
    }

};

// exports.deleteUserRole = async (req, res) => {
//     contex.getContext().accessLevel.update(
//         { isActive: false },
//         { where: { accessLevelId: req.params.accessLevelId } }
//     )
//         .then(result => {
//             res.send(encryptResponse(result));
//         }
//         )
//         .error(err => {
//             res.staus(500).send(err);
//         }
//         )
// };

// exports.updateUserRole = async (req, res) => {
//     console.log('*********desc *****', req.body.description);
//     contex.getContext().accessLevel.update(
//         req.body,
//         { where: { accessLevelId: req.body.accessLevelId } }
//     ).then(result => {
//         res.send(encryptResponse(result));
//     }
//     )
//         .error(err => {
//             res.staus(500).send(err);
//         }
//         )
// };

// exports.getAdminRoleTypePermissions = async (req, res) => {

//     contex.sequelize.query(`
//     WITH Category_Cte (categoryId, categoryName, parentCategory, parentCategoryName)  AS  
//     (  
//         SELECT ctg.admin_permission_category_id categoryId, ctg.admin_permission_category_name categoryName, 		
//         ctg.parent_category_id prentCategory,
//         CASE WHEN pctg.admin_permission_category_name IS NULL THEN ctg.admin_permission_category_name  ELSE pctg.admin_permission_category_name END prentCategoryName	
//         FROM admin_permission_category  ctg 
//         left join admin_permission_category  pctg on ctg.parent_category_id = pctg.admin_permission_category_id
//     )
//     select cat.*, 
//     ad_pms.admin_permission_id adminPermissionId, ad_pms.admin_permission_name adminPermissionName, 
//     ad_role_pms.is_view isView, ad_role_pms.is_add isAdd, ad_role_pms.is_edit isEdit, ad_role_pms.is_delete idDelete 
// 	from Category_Cte cat
//     join admin_permissions  ad_pms on cat.categoryId = ad_pms.admin_permission_category_id  
//     join admin_role_type_permission_configuration ad_role_pms on ad_pms.admin_permission_id = ad_role_pms.admin_permission_id 
// 	join admin_permission_category_configuration permissionCategoriesConfig on cat.categoryId = permissionCategoriesConfig.admin_permission_category_id
//     where  permissionCategoriesConfig.is_active = 1 and  ad_role_pms.admin_role_type_id = ${req.params.adminRoleTypId}  and 
//     permissionCategoriesConfig.admin_role_type_id = ${req.params.adminRoleTypId} 
//     order by parentCategory desc    
//     `, { type: QueryTypes.SELECT }).then((result) => {

//         // const nest = (items, id = null, link = 'parentCategory') => {
//         //    let parents =  items.filter(item => item[link] === id);
//         //    let fitems =  parents.map(item => ({ ...item, children: nest(items, item.categoryId) }));
//         //    return fitems; 
//         // }

//         const nest = (items, id = null, link = 'parentCategory') => {
//             let parents = items.filter(item => item[link] === id);
//             let fitems = parents.map(item => ({ ...item, children: item.children.concat(nest(items, item.categoryId)) }));
//             return fitems;
//         }
//         // console.log('nest', nest(result));

//         rst = [];

//         result.forEach(function (a) {

//             a.isAdd = a.isAdd === true ?  false: a.isAdd;
//             a.isDelete = a.isDelete === true ?  false: a.isDelete;
//             a.isView = a.isView === true ?  false: a.isView; 
//             a.isEdit = a.isEdit === true ?  false: a.isEdit;
//             if (!this[a.categoryName] && !this[a.parentCategoryName]) {
//                 this[a.categoryName] = {
//                     categoryId: a.categoryId, categoryName: a.categoryName, parentCategory: a.parentCategory, adminPermissionName: a.categoryName,
//                     parentCategoryName: a.parentCategoryName, children: []
//                 };
//                 rst.push(this[a.categoryName]);
//             }
//             this[a.categoryName].children.push({
//                 categoryId: a.categoryId, adminPermissionName: a.adminPermissionName,
//                 categoryName: a.categoryName, parentCategory: a.parentCategory, adminPermissionId: a.adminPermissionId,
//                 isView: a.isView, isAdd: a.isAdd, isDelete: a.isDelete, isEdit: a.isEdit,
//                 parentCategoryName: a.parentCategoryName, children: []
//             });

//         }, Object.create(null));

//         console.log(rst);
//         res.send(nest(rst));
//     });
// };