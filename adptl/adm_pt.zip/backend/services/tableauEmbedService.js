// ----------------------------------------------------------------------------
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
// ----------------------------------------------------------------------------

const fetch = require('node-fetch');

// env attributes
const tableauServer  = 'prod-apnortheast-a';
const tableauServerAPI  = `https://${tableauServer}.online.tableau.com/api/`;
const tableauAuthSignin = `${tableauServerAPI}3.4/auth/signin`;
const tableauSiteName = 'amnet';
const tableauViewerName = 'ankamma.bollimuntha@amnetdigital.com';
const tableauViewerPsd = 'ank$-so1_T';



/**
 * Get embed params for a single report for a single workspace
 * @param {string} workspaceId
 * @param {string} reportId
 * @param {string} additionalDatasetId - Optional Parameter
 * @return EmbedConfig object
 */
exports.getTableauAccessToken =  async () => {    
    const headers =  {
        'Content-Type': "application/json",
        'Accept': "application/json",
    };    
    // Get report info by calling the PowerBI REST API
    const result = await fetch(tableauAuthSignin, {
        method: 'POST',
        headers: headers,
        body: {
            "credentials": {
              "name": tableauViewerName,
              "password": tableauViewerPsd,
              "site": {
                "contentUrl": tableauSiteName
              }
            }
        }
    })

    if (!result.ok) {
        throw result;
    }
  
    return result;
}