const Sequelize = require('sequelize');
let config = require("../config");
const vault = require('../keyVault');
const azureIdentity = require("@azure/identity");
const appConfig = require("@azure/app-configuration");
const errorHandler = require('../errorHandler');


// const connectionString = 'Driver={ODBC Driver 17 for SQL Server};server=entrep-sqldb-cdw-usncz-dv-svr.database.windows.net;database=entrep-sqldb-cdw-usncz-dv-ReportingDB;Authentication=ActiveDirectoryIntegrated;';

module.exports = (() => {

  // let sq = {
  //   verifyDBConnection: () => { },
  //   getContext: () => { },
  //   otherConnection: () => { },
  //   sequelize: {}
  // }

  // try {   
  //   //const sequelize  = {};
  //   sq.sequelize = new Sequelize({
  //     dialect: 'mssql',
  //     dialectModulePath: 'msnodesqlv8/lib/sequelize',
  //     bindParam: false,
  //     dialectOptions: {
  //       options: {
  //         connectionString: connectionString
  //       },
  //     }
  //   });

  //   sq.otherConnection = (async (req, res) => {
  //     try {
  //       console.log('****************************  connn str test **********************', req.query.str);
  //       const sql = require("msnodesqlv8");
  //       let connectionString = "Driver={ODBC Driver 17 for SQL Server};server=entrep-sqldb-cdw-usncz-dv-svr.database.windows.net;database=entrep-sqldb-cdw-usncz-dv-ReportingDB;Authentication=ActiveDirectoryIntegrated;";
  //       connectionString = req.query.str ? req.query.str : connectionString;
  //       const query = "SELECT name FROM sys.databases";
  //       sql.query(connectionString, query, (err, rows) => {
  //         if (err) {
  //           errorHandler.logError(err);
  //           console.log('************************************ conn error ****************************', err);
  //           return res.status(500).json(err);
  //         }
  //         console.log(rows);
  //         res.send(rows);
  //       });
  //     } catch (ex) {
  //       console.log('************************************ conn error ex ****************************', ex);
  //       return res.status(500).json(ex)
  //     }
  //   })

  //   sq.verifyDBConnection = (async () => {
  //     console.log('verifying databse connection');
  //     try {
  //       let r = sq.otherConnection();
  //       let res = await sq.sequelize.authenticate();
  //       console.log('Connection has been established successfully.', res);

  //     } catch (ex) {
  //       console.log('db connection excption', ex);
  //     }
  //   });

  //   sq.getContext = () => {
  //     var initModels = require("../models/init-models");
  //     var contex = initModels(sequelize);
  //     return contex;
  //   }

  // } catch (e) {

  // } finally {    
  //   return sq;
  // }

});


