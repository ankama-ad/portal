const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('logger', {
    userId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
      field: 'user_id'
    },
    userName: {
      type: DataTypes.STRING(256),
      allowNull: true,
      field: 'user_name'
    },
    logLevel: {
        type: DataTypes.INTEGER,
        allowNull: true,
        field: 'log_level'
      },
      logDescription: {
        type: DataTypes.STRING(256),
        allowNull: true,
        field: 'log_description'
      },
    isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      field: 'is_active'
    },
     
  
  }, {
    sequelize,
    tableName: 'logger',
    schema: 'dbo',
    timestamps: false,
    indexes: [
      {
        name: "PK_logger",
        unique: true,
        fields: [
          { name: "id" },
        ]
      },
    ]
  });
};
