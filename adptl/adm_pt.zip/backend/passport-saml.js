// var passport = require('passport');
// var session = require('express-session');
// var fs = require('fs');
// var SamlStrategy = require('passport-saml').Strategy;
// passport.serializeUser(function (user, done) {
//   done(null, user);
// });
// passport.deserializeUser(function (user, done) {
//   done(null, user);
// });
// passport.use(new SamlStrategy(
//   {
//     path: '/login/callback',
//     entryPoint: 'https://login.microsoftonline.com/267dcacd-0757-456e-93ab-89d7068ef6b4/saml2',
//     issuer: 'mytestapp',
//     cert: fs.readFileSync('rcoe-saml.cer', 'utf-8'),
//     signatureAlgorithm: 'sha256'
//   },
//   function (profile, done) {
//     console.log('profile', profile);
//     return done(null,
//       {
//         id: profile['nameID'],
//         email: profile['http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress'],
//         displayName: profile['http://schemas.microsoft.com/identity/claims/displayname'],
//         firstName: profile['http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname'],
//         lastName: profile['http://schemas.xmlsoap.org/ws/2005/05/identity/claims/surname']
//       });
//   })
// );
// app.use(session(
//   {
//     resave: true,
//     saveUninitialized: true,
//     secret: 'this hits'
//   }));
// app.use(passport.initialize());
// app.use(passport.session());



// app.get(`/auth`, (req, res, next) => {
//     const { returnTo } = req.query
//     const state = returnTo
//       ? Buffer.from(JSON.stringify({ returnTo })).toString('base64') : undefined
//     const authenticator = passport.authenticate('github', { scope: [], state })
//     authenticator(req, res, next)
//   })
  
//   app.get('/login', (req, res, next) => {
//     const { returnTo, origin } = req.query
//     const state = returnTo ? Buffer.from(JSON.stringify({ returnTo })).toString('base64') : undefined
//     const authenticator = passport.authenticate('saml', {
//       successRedirect: '/',   
//       state: state,
//       failureRedirect: '/login'
//     });
//     req.session.state = state;
//     req.session.host = origin;
//     authenticator(req, res, next)
//   });
  
//   app.post('/login/callback',
//     passport.authenticate('saml', { failureRedirect: '/', failureFlash: true }), (req, res, next) => {
//       console.log('req done');
//       const xmlResponse = req.body.SAMLResponse;
//       const parser = new Saml2js(xmlResponse);
//       req.samlUserObject = parser.toObject();
//       req.samlResponse = req.body.SAMLResponse;
  
//       next();
//     },
//     (req, res) => {
  
//       console.info('createUserSession called');
  
//       const { state, host } = req.session;
//       const {returnTo }  = state ? JSON.parse(Buffer.from(state, 'base64').toString()): '';
//       if (typeof returnTo === 'string' && returnTo ==='undefined') {
//         returnTo = '';
//       }
  
//       // create a token
//       //  var token = jwt.sign({ id: 'ajay' }, config.Secret, {
//       //   expiresIn: config.EXPIRES_IN // expires in 24 hours
//       // });
//       // const refreshToken = randtoken.uid(256);
//       //refreshTokens[refreshToken] = User.email;
//       // console.log('refreshtoken', refreshTokens);
//       // return the information including token as JSON
  
//       // const user = await userService.getUserByEmail(req.userDetails.email);
//       // if(!user){
//       //     return res.redirect(302, `${process.env.DOMAIN_RL}/validate-sso-token?error=User Not reqistered with BrightLab`);        
//       // }
//       // const ssoResponse = loginDato.createWSSORespSameAsDeep(req.userDetails, user);
//       //const session =  await sessionService.createSession(user, null, false, req.deviceInfo, true, ssoResponse);
//       //const token = cassndraUtil.generateTimeuuid();
//       // await redisUtil.save(token, session.data, 60);
//       // res.cookie('Authorization', session);
//       //return res.redirect(302, `${process.env.DOMAIN_URL}/validate-sso-token?token=${token}`);
//       // let userInfo = {};
//       // let claimPrefix = 'httpSchemasMicrosoftComClaims;'
//       // Object.keys(req.samlUserObject).forEach(key => {       
//       //     userInfo[key.substr(claimPrefix.length)] = req.samlUserObject[key];       
//       // });
//       console.log(host);
//       res.cookie("loggedInUser", JSON.stringify(req.session.passport.user));
//       return res.redirect(302, `${host}/#/authenticate?returnTo=${returnTo}&token=${req.samlResponse}`);
  
//       // userLogin.createUserSession(res, req);
//     });
  