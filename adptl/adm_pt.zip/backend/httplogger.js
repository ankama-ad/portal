const morgan = require('morgan')
const json = require('morgan-json')
const format = json({
    method: ':method',
    url: ':url',
    port: ':req[port]',
    status: ':status',
    contentLength: ':res[content-length]',
    req: ':req[host]' + ':url', // :req[protocol]' + '://' +
    responseTime: ':response-time'
})

const { logger, logInfo } = require('./logger')
const httpLogger = morgan(format, {
    stream: {
        write: (message) => {
            const {
                method,
                url,
                port,
                status,
                contentLength,
                req,
                responseTime
            } = JSON.parse(message)

            logger.info('HTTP Access Log', {
                timestamp: new Date().toString(),
                method,
                url,
                port,
                status: Number(status),
                contentLength,
                req,
                responseTime: Number(responseTime)
            })
            //  logInfo({ level: 'info', message: 'get detpartments api',  hostname: req.hostname, 
            // port: req.port, username: 'ankam.bollimuntha@cdw.com', req: (req.protocol + "://" + req.get('host') + req.originalUrl) })
            logInfo( { level: 'INFO' , message: {
                timestamp: new Date().toString(),
                method,
                url,
                port,
                status: Number(status),
                contentLength,
                req,
                responseTime: Number(responseTime)
            }})
        }
    }
})

module.exports = httpLogger